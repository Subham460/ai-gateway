# oc-direct on Kaggle — copy-paste runbook

Every step below is **one cell, copy-paste as-is**. Paths are preset to your uploaded zip at
`/kaggle/working/oc-direct/oc-direct-2026-11-13.zip`. Cells are idempotent: re-running them replaces state instead of piling up.

Only external requirement: **Settings → Internet → On** (phone-verified account).

Run order: **1 → 2 → 3 → 4 → 5 → 6**. Step 7+ is optional.

---

## Cell 1 — stage the zip (handles flat *and* nested archives)

```python
import os, shutil, subprocess

ZIP  = "/kaggle/working/oc-direct/oc-direct-2026-11-13.zip"
DEST = "/kaggle/working/oc-direct"
STAGE = "/tmp/ocd-stage"

assert os.path.exists(ZIP), f"zip not found at {ZIP} — run: !find /kaggle -name '*.zip'"
shutil.rmtree(STAGE, ignore_errors=True); os.makedirs(STAGE, exist_ok=True)
r = subprocess.run(["unzip", "-q", "-o", ZIP, "-d", STAGE], capture_output=True, text=True)
assert r.returncode == 0, r.stderr

root = STAGE if os.path.exists(f"{STAGE}/package.json") else f"{STAGE}/oc-direct"
assert os.path.exists(f"{root}/package.json"), f"unexpected layout in {STAGE}: {os.listdir(STAGE)}"

os.makedirs(DEST, exist_ok=True)
for name in os.listdir(root):
    if name == os.path.basename(ZIP):      # keep your uploaded zip where it is
        continue
    src, dst = f"{root}/{name}", f"{DEST}/{name}"
    if os.path.isdir(src):
        shutil.copytree(src, dst, dirs_exist_ok=True)
    else:
        shutil.copy2(src, dst)

os.chdir(DEST)
print("layout      :", "nested" if root.endswith("/oc-direct") else "flat")
print("entries     :", len([e for e in os.listdir(DEST) if e != os.path.basename(ZIP)]))
print("prompt bytes:", os.path.getsize("src/assets/system-prompt.txt"), "(expect 8605)")
print("ok          :", os.path.exists("package.json") and os.path.isdir("src/assets"))
```

Expect `prompt bytes: 8605 (expect 8605)` and `ok: True`.

---

## Cell 2 — install Bun

```python
import os, subprocess

BUN = os.path.expanduser("~/.bun/bin/bun")
if not os.path.exists(BUN):
    r = subprocess.run("curl -fsSL https://bun.sh/install | bash", shell=True, capture_output=True, text=True)
    assert os.path.exists(BUN), f"bun install failed:\n{r.stderr[-800:]}"

os.environ["PATH"] = os.path.dirname(BUN) + ":" + os.environ["PATH"]
print("bun", subprocess.run([BUN, "--version"], capture_output=True, text=True).stdout.strip())
```

---

## Cell 3 — unit tests (offline, zero quota)

```python
import os, subprocess
os.chdir("/kaggle/working/oc-direct")
print(subprocess.run(["bun", "test"], capture_output=True, text=True).stdout[-600:])
```

Expect `52 pass / 0 fail / 140 expect() calls`.

Optional typecheck (downloads 2 dev packages, no quota):

```python
import subprocess
print(subprocess.run(["bun", "install"], capture_output=True, text=True).stdout[-300:])
print(subprocess.run(["bun", "run", "typecheck"], capture_output=True, text=True).stdout[-300:])
```

---

## Cell 4 — write `.env` with a fresh gateway key

```python
import os, secrets

os.chdir("/kaggle/working/oc-direct")
key = secrets.token_hex(24)
with open(".env", "w") as f:
    f.write(f"OCD_KEYS={key}:kaggle\nOCD_HOST=127.0.0.1\nOCD_PORT=8787\nOCD_LOG_LEVEL=info\n")
os.chmod(".env", 0o600)
with open("/tmp/ocd-key", "w") as f:
    f.write(key)
print("gateway key:", key)
```

Keep this key — it is the `api_key` for every client. Swap `OCD_HOST` to `0.0.0.0` only if you also open a tunnel (step 8).

---

## Cell 5 — start the server (kills any previous instance first)

```python
import os, subprocess, time, signal

os.chdir("/kaggle/working/oc-direct")
os.environ["PATH"] = os.path.expanduser("~/.bun/bin") + ":" + os.environ["PATH"]

subprocess.run(["pkill", "-f", "src/server.ts"], capture_output=True)   # idempotent restart
time.sleep(1)

log = open("/tmp/ocd.log", "w")
proc = subprocess.Popen(["bash", "./run.sh"], cwd="/kaggle/working/oc-direct",
                        stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
time.sleep(3)
print(open("/tmp/ocd.log").readline().strip())

out = subprocess.run(["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", "http://127.0.0.1:8787/healthz"],
                     capture_output=True, text=True).stdout
print("healthz", out, "| pid", proc.pid)
```

Expect the `listening` JSON line and `healthz 200`.

**Switch tool mode** (only if the client's replies contain `<|DSML| invoke …>` or other tool markup as text):

```python
import os, subprocess, time
os.chdir("/kaggle/working/oc-direct")
lines = [l for l in open(".env").read().splitlines()
         if not l.startswith(("OCD_TOOLS_MODE", "OCD_TOOL_CHOICE"))]
lines += ["OCD_TOOLS_MODE=full", "OCD_TOOL_CHOICE=auto"]
open(".env", "w").write("\n".join(lines) + "\n")
subprocess.run(["pkill", "-f", "src/server.ts"]); time.sleep(1)
subprocess.Popen(["bash", "./run.sh"], cwd="/kaggle/working/oc-direct",
                 stdout=open("/tmp/ocd.log", "w"), stderr=subprocess.STDOUT, start_new_session=True)
time.sleep(3); print(open("/tmp/ocd.log").readline()[:140])
```

Revert by replacing the two appended lines with `OCD_TOOLS_MODE=read` and `OCD_TOOL_CHOICE=none`, then restarting the same way. Chat mode also sets `OCD_CHAT_GUARD=1` (default), which stops the model from writing tool markup as text.

---

## Cell 6 — smoke test: one real completion (~2k prompt tokens)

```python
import subprocess
out = subprocess.run(
    ["curl", "-s", "http://127.0.0.1:8787/v1/chat/completions",
     "-H", "content-type: application/json",
     "-H", f"authorization: Bearer {open('/tmp/ocd-key').read().strip()}",
     "-d", '{"model":"glm-5.3-flash-free","messages":[{"role":"user","content":"say OK"}],"max_tokens":16}'],
    capture_output=True, text=True).stdout
print(out[:400])
```

Expect `"content":"OK"` and `"usage":{"prompt_tokens":2038,...}`.

A `429 FreeUsageLimitError` means contract drift or spent quota — jump to **Diagnostics**.

---

## Cell 7 — use it from Python (the normal way)

```python
from openai import OpenAI

client = OpenAI(base_url="http://127.0.0.1:8787/v1",
                api_key=open("/tmp/ocd-key").read().strip())

r = client.chat.completions.create(
    model="glm-5.3-flash-free",
    messages=[{"role": "user", "content": "one sentence about tide pools"}],
)
print(r.choices[0].message.content)
print(r.usage)
```

Streaming variant:

```python
stream = client.chat.completions.create(
    model="deepseek-v4.1-flash-free",
    messages=[{"role": "user", "content": "count to five"}],
    stream=True,
)
for chunk in stream:
    d = chunk.choices[0].delta
    print(getattr(d, "reasoning_content", "") or d.content or "", end="")
```

---

## Cell 8 — optional: reach it from outside the notebook

```python
import os, subprocess, time, re

if not os.path.exists("/tmp/cloudflared"):
    subprocess.run("curl -fsSL -o /tmp/cloudflared "
                   "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64",
                   shell=True, check=True)
    os.chmod("/tmp/cloudflared", 0o755)

tun = subprocess.Popen(["/tmp/cloudflared", "tunnel", "--url", "http://127.0.0.1:8787"],
                       stdout=open("/tmp/tunnel.log", "w"), stderr=subprocess.STDOUT,
                       start_new_session=True)
time.sleep(8)
log = open("/tmp/tunnel.log").read()
url = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", log)
print("public URL:", url.group(0) if url else "not yet — check /tmp/tunnel.log")
```

That URL proxies your quota to the internet the moment it exists. It is only safe because step 4 put a key on the listener — keep `OCD_ALLOW_ANONYMOUS` unset. Close it by killing `cloudflared` when done:

```python
import subprocess; subprocess.run(["pkill", "-f", "cloudflared"])
```

---

## Cell 9 — optional: full contract check (12 live calls, once per session)

```python
import os, subprocess
os.chdir("/kaggle/working/oc-direct")
print(subprocess.run(["bun", "run", "test:integration"], capture_output=True, text=True).stdout[-1200:])
```

---

## Diagnostics

```python
import subprocess
for cmd in (["pwd"], ["ls", "-1"], ["pgrep", "-af", "src/server.ts"]):
    print(subprocess.run(cmd, capture_output=True, text=True).stdout.strip())
print(open("/tmp/ocd.log").read()[-1500:])
```

```python
# is it up, is auth enforced, is the circuit closed?
import subprocess, json
key = open("/tmp/ocd-key").read().strip()
for label, args in [
    ("healthz",        ["curl","-s","-o","/dev/null","-w","%{http_code}","http://127.0.0.1:8787/healthz"]),
    ("readyz",         ["curl","-s","http://127.0.0.1:8787/readyz"]),
    ("models no key",  ["curl","-s","-o","/dev/null","-w","%{http_code}","http://127.0.0.1:8787/v1/models"]),
    ("models with key",["curl","-s","-o","/dev/null","-w","%{http_code}","-H",f"authorization: Bearer {key}","http://127.0.0.1:8787/v1/models"]),
]:
    print(label, "=", subprocess.run(args, capture_output=True, text=True).stdout.strip())
```

Expected: `healthz 200`, `readyz` with `"circuit":"closed"`, `models no key 401`, `models with key 200`.

```python
# only if everything 429s: which requirement moved?
import os, subprocess
os.chdir("/kaggle/working/oc-direct")
print(subprocess.run(["bun", "run", "verify:contract"], capture_output=True, text=True).stdout[-1000:])
```

| Symptom | Fix |
| --- | --- |
| `zip not found` | `!find /kaggle -name '*.zip'` and edit `ZIP` in cell 1 |
| `unexpected layout` | dataset was auto-extracted; point `ZIP` at the dataset path or copy the extracted tree into `DEST` |
| `bun: command not found` | rerun cell 2 (PATH is per kernel, lost on restart) |
| `Could not resolve host` | internet toggle is off |
| `Bun could not find a package.json file` | you're not in `/kaggle/working/oc-direct`; rerun cell 1 |
| `429 FreeUsageLimitError` | run `verify:contract`; quota resets on the provider's clock |
| empty `content`, `finish_reason: length` | reasoning ate the budget — raise `max_tokens` or set `OCD_REASONING_HEADROOM_TOKENS=512` |
| server died between cells | kernel restarted — rerun cells 2, 5 (cell 4's key is still in `/tmp/ocd-key` unless `/tmp` cleared) |

---

## Session facts

- `/kaggle/working` survives only via **Save Version**; `~/.bun` and `/tmp` are gone next session → rerun cells 2, 5.
- Notebooks are public by default; a key pasted into a cell is published. Prefer Kaggle **Secrets** (`from kaggle_secrets import UserSecretsClient`) over cell 4's printed key if you'll share the notebook.
- No inbound ports, ~12 h session cap: this is a demo runner, not a host.
- Quota is per account. Kaggle gives a clean environment, not extra allowance.
