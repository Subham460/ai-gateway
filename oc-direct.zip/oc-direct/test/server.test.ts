import { describe, expect, test } from "bun:test";
import { loadConfig } from "../src/config.ts";
import { createLogger } from "../src/logger.ts";
import { createApp } from "../src/server.ts";

const silent = createLogger("error");

/** Bun/undici type `Response.json()` as `unknown`; tests assert against dynamic JSON. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function jsonOf(response: Response): Promise<any> {
  return response.json() as Promise<any>;
}


function app(env: Record<string, string> = {}) {
  return createApp(loadConfig({ OCD_ALLOW_ANONYMOUS: "1", ...env }), silent);
}

function post(application: ReturnType<typeof app>, body: unknown, headers: Record<string, string> = {}) {
  return application.fetch(
    new Request("http://localhost/v1/chat/completions", {
      method: "POST",
      headers: { "content-type": "application/json", ...headers },
      body: JSON.stringify(body),
    }),
  );
}

describe("routes", () => {
  test("health and readiness answer without upstream", async () => {
    const application = app();
    expect((await application.fetch(new Request("http://localhost/healthz"))).status).toBe(200);
    const ready = await application.fetch(new Request("http://localhost/readyz"));
    expect(ready.status).toBe(200);
    expect((await jsonOf(ready)).status).toBe("ready");
  });

  test("lists the catalog", async () => {
    const response = await app().fetch(new Request("http://localhost/v1/models"));
    expect(response.status).toBe(200);
    const payload = await jsonOf(response);
    expect(payload.object).toBe("list");
    expect(payload.data.length).toBeGreaterThan(5);
    expect(payload.data[0]).toMatchObject({ object: "model", owned_by: "opencode" });
  });

  test("resolves a single model and 404s otherwise", async () => {
    const application = app();
    expect((await application.fetch(new Request("http://localhost/v1/models/glm-5.3-flash-free"))).status).toBe(200);
    expect((await application.fetch(new Request("http://localhost/v1/models/nope"))).status).toBe(404);
  });

  test("unknown routes 404", async () => {
    expect((await app().fetch(new Request("http://localhost/v1/embeddings"))).status).toBe(404);
  });

  test("GET on completions is 405", async () => {
    expect((await app().fetch(new Request("http://localhost/v1/chat/completions"))).status).toBe(405);
  });

  test("rejects unknown models before contacting upstream", async () => {
    const response = await post(app(), { model: "nope", messages: [{ role: "user", content: "hi" }] });
    expect(response.status).toBe(404);
    expect((await jsonOf(response)).error.type).toBe("not_found_error");
  });

  test("rejects malformed payloads", async () => {
    const application = app();
    expect((await post(application, { model: "deepseek-v4.1-flash-free" })).status).toBe(400);
    expect(
      (await post(application, { model: "deepseek-v4.1-flash-free", messages: [] })).status,
    ).toBe(400);
    expect(
      (
        await application.fetch(
          new Request("http://localhost/v1/chat/completions", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: "{not json",
          }),
        )
      ).status,
    ).toBe(400);
  });

  test("enforces bearer auth when keys are configured", async () => {
    const application = createApp(loadConfig({ OCD_KEYS: "supersecret1:alice" }), silent);
    const denied = await application.fetch(new Request("http://localhost/v1/models"));
    expect(denied.status).toBe(401);
    expect((await jsonOf(denied)).error.type).toBe("authentication_error");

    const wrong = await application.fetch(
      new Request("http://localhost/v1/models", { headers: { authorization: "Bearer wrong-key-value" } }),
    );
    expect(wrong.status).toBe(401);

    const allowed = await application.fetch(
      new Request("http://localhost/v1/models", { headers: { authorization: "Bearer supersecret1" } }),
    );
    expect(allowed.status).toBe(200);
  });

  test("health stays public when keys are configured", async () => {
    const application = createApp(loadConfig({ OCD_KEYS: "supersecret1:alice" }), silent);
    expect((await application.fetch(new Request("http://localhost/healthz"))).status).toBe(200);
    expect((await application.fetch(new Request("http://localhost/metrics"))).status).toBe(401);
    expect(
      (
        await application.fetch(
          new Request("http://localhost/metrics", { headers: { authorization: "Bearer supersecret1" } }),
        )
      ).status,
    ).toBe(200);
  });

  test("exposes prometheus metrics", async () => {
    const application = app();
    await application.fetch(new Request("http://localhost/healthz"));
    const response = await application.fetch(new Request("http://localhost/metrics"));
    const text = await response.text();
    expect(text).toContain("ocd_http_requests_total");
    expect(text).toContain("ocd_inflight_requests");
  });
});
