import { describe, expect, test } from "bun:test";
import { loadConfig, parseKeys } from "../src/config.ts";

describe("parseKeys", () => {
  test("parses secret:name pairs", () => {
    expect(parseKeys("supersecret1:alice,supersecret2:bob")).toEqual([
      { id: "alice", secret: "supersecret1" },
      { id: "bob", secret: "supersecret2" },
    ]);
  });

  test("derives a name when none is given", () => {
    expect(parseKeys("supersecret1")).toEqual([{ id: "key-1", secret: "supersecret1" }]);
  });

  test("allows colons inside the secret", () => {
    expect(parseKeys("prefix-a:b:c:name")).toEqual([{ id: "name", secret: "prefix-a:b:c" }]);
  });

  test("rejects short and duplicate secrets", () => {
    expect(() => parseKeys("short")).toThrow();
    expect(() => parseKeys("supersecret1:a,supersecret1:b")).toThrow();
  });

  test("returns an empty list for blank input", () => {
    expect(parseKeys("")).toEqual([]);
    expect(parseKeys(" , ")).toEqual([]);
  });
});

describe("loadConfig", () => {
  test("requires credentials unless anonymous access is explicit", () => {
    expect(() => loadConfig({})).toThrow();
    expect(loadConfig({ OCD_ALLOW_ANONYMOUS: "1" }).allowAnonymous).toBe(true);
  });

  test("applies defaults", () => {
    const config = loadConfig({ OCD_KEYS: "supersecret1:alice" });
    expect(config.port).toBe(8787);
    expect(config.host).toBe("127.0.0.1");
    expect(config.upstreamUrl).toBe("https://opencode.ai/inference/openai/v1");
    expect(config.toolsMode).toBe("read");
    expect(config.toolChoice).toBe("none");
    expect(config.maxConcurrency).toBe(16);
  });

  test("rejects invalid values", () => {
    expect(() => loadConfig({ OCD_ALLOW_ANONYMOUS: "1", OCD_PORT: "not-a-port" })).toThrow();
    expect(() => loadConfig({ OCD_ALLOW_ANONYMOUS: "1", OCD_LOG_LEVEL: "loud" })).toThrow();
    expect(() => loadConfig({ OCD_ALLOW_ANONYMOUS: "1", OCD_TOOLS_MODE: "all" })).toThrow();
    expect(() => loadConfig({ OCD_ALLOW_ANONYMOUS: "1", OCD_MAX_CONCURRENCY: "0" })).toThrow();
  });

  test("normalizes the upstream url", () => {
    expect(
      loadConfig({ OCD_ALLOW_ANONYMOUS: "1", OCD_UPSTREAM_URL: "https://example.test/v1///" }).upstreamUrl,
    ).toBe("https://example.test/v1");
  });
});
