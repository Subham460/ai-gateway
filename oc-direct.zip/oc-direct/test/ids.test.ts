import { describe, expect, test } from "bun:test";
import { decodeSessionID, isSessionID, sessionID } from "../src/ids.ts";

const ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

/** Low 36 bits of a millisecond timestamp — the part encoded in the id prefix. */
const low36 = (ms: number) => Number(BigInt(ms) & 0xfffffffffn);

describe("sessionID", () => {
  test("matches the wire format", () => {
    const id = sessionID();
    expect(id.startsWith("ses_")).toBe(true);
    expect(id).toHaveLength(4 + 12 + 14);
    expect(id.slice(4, 16)).toMatch(/^[0-9a-f]{12}$/);
    for (const ch of id.slice(16)) expect(ALPHABET).toContain(ch);
    expect(isSessionID(id)).toBe(true);
  });

  test("is unique under load", () => {
    const seen = new Set<string>();
    for (let i = 0; i < 5000; i++) seen.add(sessionID());
    expect(seen.size).toBe(5000);
  });

  test("encodes the timestamp", () => {
    const now = 1_760_000_000_123;
    const decoded = decodeSessionID(sessionID(now))!;
    expect(decoded).not.toBeNull();
    expect(decoded.msLow36).toBe(low36(now));
    expect(decoded.counter).toBe(1); // first id in a fresh millisecond
  });

  test("increments the counter within the same millisecond", () => {
    const now = 1_760_000_000_777;
    const counters = [sessionID(now), sessionID(now), sessionID(now)].map(
      (id) => decodeSessionID(id)!.counter,
    );
    expect(counters).toEqual([1, 2, 3]);
  });

  test("resets the counter when the clock advances", () => {
    const a = decodeSessionID(sessionID(1_760_000_001_000))!;
    const b = decodeSessionID(sessionID(1_760_000_002_000))!;
    expect(a.counter).toBe(1);
    expect(b.counter).toBe(1);
    expect(b.msLow36).toBe(low36(1_760_000_002_000));
  });

  test("rejects malformed identifiers", () => {
    expect(isSessionID("ses_short")).toBe(false);
    expect(isSessionID("ses_" + "z".repeat(26))).toBe(false);
    expect(isSessionID("per_" + "0".repeat(26))).toBe(false);
    expect(decodeSessionID("nope")).toBeNull();
  });

  test("low 36 bits survive round-trip across a wide time range", () => {
    for (const now of [1_700_000_000_000, 1_760_000_000_000, 1_800_000_000_000]) {
      expect(decodeSessionID(sessionID(now))!.msLow36).toBe(low36(now));
    }
  });
});
