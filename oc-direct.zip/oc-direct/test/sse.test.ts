import { describe, expect, test } from "bun:test";
import { SSEParser, extractData } from "../src/sse.ts";

describe("extractData", () => {
  test("returns the payload of a single data line", () => {
    expect(extractData('data: {"a":1}')).toBe('{"a":1}');
  });

  test("tolerates a missing space after the colon", () => {
    expect(extractData('data:{"a":1}')).toBe('{"a":1}');
  });

  test("joins multi-line data fields", () => {
    expect(extractData("data: line1\ndata: line2")).toBe("line1\nline2");
  });

  test("ignores comments and other fields", () => {
    expect(extractData(": keep-alive\nevent: message\ndata: x")).toBe("x");
  });

  test("returns null when there is no data", () => {
    expect(extractData(": ping")).toBeNull();
    expect(extractData("data:   ")).toBeNull();
  });
});

describe("SSEParser", () => {
  const stream = [
    'data: {"n":1}\n\n',
    'data: {"n":2}\r\n\r\n',
    ": comment\n\n",
    "data: [DONE]\n\n",
  ].join("");

  test("parses whole events", () => {
    const parser = new SSEParser();
    const out = parser.push(stream);
    expect(out).toEqual(['{"n":1}', '{"n":2}', "[DONE]"]);
  });

  test("is invariant to chunk boundaries", () => {
    for (const size of [1, 2, 3, 5, 7, 11]) {
      const parser = new SSEParser();
      const out: string[] = [];
      for (let i = 0; i < stream.length; i += size) {
        out.push(...parser.push(stream.slice(i, i + size)));
      }
      out.push(...parser.flush());
      expect(out).toEqual(['{"n":1}', '{"n":2}', "[DONE]"]);
    }
  });

  test("holds an unterminated trailing event until flush", () => {
    const parser = new SSEParser();
    expect(parser.push('data: {"n":9}')).toEqual([]);
    expect(parser.flush()).toEqual(['{"n":9}']);
  });

  test("does not emit empty events", () => {
    const parser = new SSEParser();
    expect(parser.push("\n\n\n\n")).toEqual([]);
  });
});
