/**
 * Reasoning-channel mapping, exercised through the real HTTP surface with the
 * upstream transport stubbed. The live endpoint emits `delta.reasoning_content`
 * before `delta.content` on hybrid models; the gateway must either pass it
 * through, fold it into the answer, or drop it, per `OCD_REASONING_MODE`.
 */

import { afterEach, describe, expect, test } from "bun:test";
import { loadConfig } from "../src/config.ts";
import { createLogger } from "../src/logger.ts";
import { createApp } from "../src/server.ts";

const silent = createLogger("error");

const FRAMES = [
  { choices: [{ index: 0, delta: { role: "assistant", content: "" }, finish_reason: null }] },
  { choices: [{ index: 0, delta: { reasoning_content: "Think" }, finish_reason: null }] },
  { choices: [{ index: 0, delta: { reasoning_content: "ing." }, finish_reason: null }] },
  { choices: [{ index: 0, delta: { content: "Answer." }, finish_reason: null }] },
  { choices: [{ index: 0, delta: {}, finish_reason: "stop" }], usage: { prompt_tokens: 11, completion_tokens: 7, total_tokens: 18, completion_tokens_details: { reasoning_tokens: 5 } } },
];

function sseBody(): string {
  return `${FRAMES.map((frame) => `data: ${JSON.stringify(frame)}\n\n`).join("")}data: [DONE]\n\n`;
}

const originalFetch = globalThis.fetch;
let calls = 0;

function stubUpstream(): void {
  calls = 0;
  globalThis.fetch = (async () => {
    calls += 1;
    return new Response(sseBody(), { status: 200, headers: { "content-type": "text/event-stream" } });
  }) as unknown as typeof fetch;
}

afterEach(() => {
  globalThis.fetch = originalFetch;
});

function app(env: Record<string, string> = {}) {
  return createApp(loadConfig({ OCD_ALLOW_ANONYMOUS: "1", ...env }), silent);
}

const request = (body: unknown) =>
  new Request("http://localhost/v1/chat/completions", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });

const MESSAGES = [{ role: "user", content: "hi" }];

function parseFrames(raw: string): Array<Record<string, any>> {
  return raw
    .split("\n\n")
    .map((block) => block.trim())
    .filter((block) => block.startsWith("data: "))
    .map((block) => block.slice(6))
    .filter((payload) => payload !== "[DONE]")
    .map((payload) => JSON.parse(payload) as Record<string, any>);
}

describe("reasoning passthrough", () => {
  test("streams reasoning_content as its own delta by default", async () => {
    stubUpstream();
    const response = await app().fetch(request({ model: "deepseek-v4.1-flash-free", messages: MESSAGES, stream: true }));
    expect(response.status).toBe(200);

    const frames = parseFrames(await response.text());
    const reasoning = frames.map((f) => f.choices?.[0]?.delta?.reasoning_content ?? "").join("");
    const content = frames.map((f) => f.choices?.[0]?.delta?.content ?? "").join("");
    expect(reasoning).toBe("Thinking.");
    expect(content).toContain("Answer.");
    expect(calls).toBe(1);
  });

  test("separates reasoning from content in non-streaming responses", async () => {
    stubUpstream();
    const response = await app().fetch(request({ model: "deepseek-v4.1-flash-free", messages: MESSAGES }));
    const body = (await response.json()) as any;
    expect(body.choices[0].message.reasoning_content).toBe("Thinking.");
    expect(body.choices[0].message.content).toBe("Answer.");
    expect(body.usage.completion_tokens_details.reasoning_tokens).toBe(5);
  });

  test("OCD_REASONING_MODE=content folds reasoning ahead of the answer", async () => {
    stubUpstream();
    const application = app({ OCD_REASONING_MODE: "content" });

    const streamed = await application.fetch(
      request({ model: "deepseek-v4.1-flash-free", messages: MESSAGES, stream: true }),
    );
    const frames = parseFrames(await streamed.text());
    expect(frames.every((f) => f.choices?.[0]?.delta?.reasoning_content === undefined)).toBe(true);
    expect(frames.map((f) => f.choices?.[0]?.delta?.content ?? "").join("")).toBe("Thinking.Answer.");

    stubUpstream();
    const plain = await application.fetch(request({ model: "deepseek-v4.1-flash-free", messages: MESSAGES }));
    const body = (await plain.json()) as any;
    expect(body.choices[0].message.content).toBe("Thinking.Answer.");
    expect(body.choices[0].message.reasoning_content).toBeUndefined();
  });

  test("OCD_REASONING_MODE=drop discards the reasoning channel", async () => {
    stubUpstream();
    const response = await app({ OCD_REASONING_MODE: "drop" }).fetch(
      request({ model: "deepseek-v4.1-flash-free", messages: MESSAGES, stream: true }),
    );
    const frames = parseFrames(await response.text());
    expect(frames.every((f) => f.choices?.[0]?.delta?.reasoning_content === undefined)).toBe(true);
    expect(frames.map((f) => f.choices?.[0]?.delta?.content ?? "").join("")).toContain("Answer.");
  });

  test("counts reasoning tokens in the metrics registry", async () => {
    stubUpstream();
    const application = app();
    await application.fetch(request({ model: "deepseek-v4.1-flash-free", messages: MESSAGES }));
    const metrics = await (await application.fetch(new Request("http://localhost/metrics"))).text();
    expect(metrics).toContain('ocd_reasoning_tokens_total 5');
  });

  test("adds reasoning headroom to the upstream completion budget", async () => {
    let sent: any = null;
    globalThis.fetch = (async (_url: string, init: { body: string }) => {
      sent = JSON.parse(init.body);
      return new Response(sseBody(), { status: 200, headers: { "content-type": "text/event-stream" } });
    }) as unknown as typeof fetch;

    const response = await app({ OCD_REASONING_HEADROOM_TOKENS: "2048" }).fetch(
      request({ model: "deepseek-v4.1-flash-free", messages: MESSAGES, max_completion_tokens: 64 }),
    );
    expect(response.status).toBe(200);
    await response.text();
    expect(sent.max_completion_tokens).toBe(64 + 2048);
  });

  test("headroom never exceeds the model output ceiling", async () => {
    let sent: any = null;
    globalThis.fetch = (async (_url: string, init: { body: string }) => {
      sent = JSON.parse(init.body);
      return new Response(sseBody(), { status: 200, headers: { "content-type": "text/event-stream" } });
    }) as unknown as typeof fetch;

    const response = await app({ OCD_REASONING_HEADROOM_TOKENS: "16000" }).fetch(
      request({ model: "flint-40b-free", messages: MESSAGES, max_completion_tokens: 8000 }),
    );
    await response.text();
    expect(sent.max_completion_tokens).toBe(16_384);
    expect(response.status).toBe(200);
  });
});
