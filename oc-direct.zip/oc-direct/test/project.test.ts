import { describe, expect, test } from "bun:test";
import { mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { projectIdStateDir, resolveProjectId } from "../src/project.ts";

const SHAPE = /^[0-9a-f]{40}$/;

function tempState(): string {
  return mkdtempSync(join(tmpdir(), "ocd-project-"));
}

describe("resolveProjectId", () => {
  test("uses an explicit override verbatim", () => {
    const id = resolveProjectId({ OCD_PROJECT_ID: "abc" });
    expect(id).toEqual({ id: "abc", source: "env", stateFile: null });
  });

  test("mints and persists a 40-hex id on a fresh install", () => {
    const dir = tempState();
    const resolved = resolveProjectId({ OCD_STATE_DIR: dir }, "/srv/oc-direct");
    expect(SHAPE.test(resolved.id)).toBe(true);
    expect(resolved.source).toBe("derived");
    expect(resolved.stateFile).toBe(join(dir, "project-id"));
    expect(readFileSync(resolved.stateFile!, "utf8").trim()).toBe(resolved.id);
  });

  test("reuses the persisted id across processes", () => {
    const dir = tempState();
    const file = join(dir, "project-id");
    writeFileSync(file, "0123456789abcdef0123456789abcdef01234567\n");
    const resolved = resolveProjectId({ OCD_STATE_DIR: dir });
    expect(resolved).toEqual({
      id: "0123456789abcdef0123456789abcdef01234567",
      source: "state",
      stateFile: file,
    });
  });

  test("regenerates a corrupt state file instead of trusting it", () => {
    const dir = tempState();
    writeFileSync(join(dir, "project-id"), "not-a-project-id");
    const resolved = resolveProjectId({ OCD_STATE_DIR: dir });
    expect(SHAPE.test(resolved.id)).toBe(true);
  });

  test("stays stable when the state directory is unwritable", () => {
    const a = resolveProjectId({ OCD_STATE_DIR: "/proc/definitely-not-writable" }, "/srv/x");
    const b = resolveProjectId({ OCD_STATE_DIR: "/proc/definitely-not-writable-2" }, "/srv/x");
    expect(a.stateFile).toBeNull();
    expect(a.id).toBe(b.id);
  });

  test("prefers OCD_STATE_DIR, then XDG_STATE_HOME, then HOME", () => {
    expect(projectIdStateDir({ OCD_STATE_DIR: "/a" })).toBe("/a");
    expect(projectIdStateDir({ XDG_STATE_HOME: "/b" })).toBe("/b/oc-direct");
    expect(projectIdStateDir({ HOME: "/c" })).toBe("/c/.local/state/oc-direct");
  });
});
