/**
 * Live end-to-end verification against the real OpenCode free-tier gateway.
 *
 *   bun run test/integration.ts
 *
 * Starts the service in-process on an ephemeral port with anonymous access and
 * exercises every public route plus real completions (non-stream, stream,
 * multi-turn, second model, system override). Exits non-zero on any failure.
 *
 * Consumes a small amount of free-tier quota: every completion is capped at
 * 96 output tokens.
 */

import { loadConfig } from "../src/config.ts";
import { createLogger } from "../src/logger.ts";
import { startServer } from "../src/server.ts";

const log = createLogger("warn");

/** Bun/undici type `Response.json()` as `unknown`; tests assert against dynamic JSON. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function jsonOf(response: Response): Promise<any> {
  return response.json() as Promise<any>;
}


interface Check {
  name: string;
  ok: boolean;
  detail: string;
  ms: number;
}

const checks: Check[] = [];

async function check(name: string, fn: () => Promise<string>): Promise<void> {
  const started = Date.now();
  try {
    const detail = await fn();
    checks.push({ name, ok: true, detail, ms: Date.now() - started });
    console.log(`PASS  ${name}  ${detail}  (${Date.now() - started}ms)`);
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    checks.push({ name, ok: false, detail, ms: Date.now() - started });
    console.log(`FAIL  ${name}  ${detail}`);
  }
}

function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

const config = loadConfig({
  OCD_ALLOW_ANONYMOUS: "1",
  OCD_PORT: "0",
  OCD_HOST: "127.0.0.1",
  OCD_LOG_LEVEL: "warn",
  OCD_RATE_LIMIT_RPM: "100000",
});

const server = startServer({ ...config, port: 0 }, log);
const base = server.url;

const post = (body: unknown, headers: Record<string, string> = {}) =>
  fetch(`${base}/v1/chat/completions`, {
    method: "POST",
    headers: { "content-type": "application/json", ...headers },
    body: JSON.stringify(body),
  });

const MODEL = "deepseek-v4.1-flash-free";

console.log(`oc-direct integration run against ${base}\n`);

await check("health", async () => {
  const response = await fetch(`${base}/healthz`);
  assert(response.status === 200, `status ${response.status}`);
  const body = await jsonOf(response);
  assert(body.status === "ok", "body.status !== ok");
  return `version ${body.version}`;
});

await check("readiness", async () => {
  const response = await fetch(`${base}/readyz`);
  const body = await jsonOf(response);
  assert(response.status === 200, `status ${response.status}`);
  assert(body.circuit === "closed", `circuit ${body.circuit}`);
  return `concurrency max ${body.concurrency.max}`;
});

await check("model catalog", async () => {
  const response = await fetch(`${base}/v1/models`);
  assert(response.status === 200, `status ${response.status}`);
  const body = await jsonOf(response);
  assert(Array.isArray(body.data) && body.data.length >= 10, "catalog too small");
  return `${body.data.length} models`;
});

await check("model detail", async () => {
  const response = await fetch(`${base}/v1/models/${MODEL}`);
  assert(response.status === 200, `status ${response.status}`);
  const body = await jsonOf(response);
  assert(body.id === MODEL, "wrong id");
  return `context ${body.context_window}`;
});

await check("metrics", async () => {
  const response = await fetch(`${base}/metrics`);
  const text = await response.text();
  assert(response.status === 200, `status ${response.status}`);
  assert(text.includes("ocd_http_requests_total"), "missing counter");
  return `${text.split("\n").length - 1} series lines`;
});

await check("non-stream completion", async () => {
  const response = await post({
    model: MODEL,
    messages: [{ role: "user", content: "Reply with exactly: GATEWAY_OK" }],
    max_completion_tokens: 32,
  });
  assert(response.status === 200, `status ${response.status}: ${await response.clone().text()}`);
  const body = await jsonOf(response);
  const content: string = body.choices?.[0]?.message?.content ?? "";
  assert(body.object === "chat.completion", "wrong object");
  assert(content.includes("GATEWAY_OK"), `content: ${JSON.stringify(content)}`);
  assert(body.usage?.total_tokens > 0, "missing usage");
  return `"${content.trim()}" · ${body.usage.total_tokens} tokens`;
});

await check("streaming completion", async () => {
  const response = await post({
    model: MODEL,
    messages: [{ role: "user", content: "Count 1 to 3, comma separated." }],
    stream: true,
    stream_options: { include_usage: true },
    max_completion_tokens: 32,
  });
  assert(response.status === 200, `status ${response.status}`);
  assert((response.headers.get("content-type") ?? "").includes("text/event-stream"), "not an event stream");

  const raw = await response.text();
  const frames = raw
    .split("\n\n")
    .map((block) => block.trim())
    .filter((block) => block.startsWith("data: "))
    .map((block) => block.slice(6));

  assert(frames.at(-1) === "[DONE]", "missing [DONE]");
  const parsed = frames
    .filter((f) => f !== "[DONE]")
    .map((f) => JSON.parse(f) as { choices?: Array<{ delta?: { content?: string } }>; usage?: { total_tokens: number } });

  const first = parsed[0]?.choices?.[0]?.delta;
  assert(first?.content === "", "first frame must open with the assistant role");
  const text = parsed.map((p) => p.choices?.[0]?.delta?.content ?? "").join("");
  const usage = parsed.find((p) => p.usage)?.usage;
  assert(text.includes("1"), `no content: ${JSON.stringify(text)}`);
  assert(usage && usage.total_tokens > 0, "missing usage frame");
  return `${parsed.length} frames · "${text.trim()}" · ${usage.total_tokens} tokens`;
});

await check("multi-turn context", async () => {
  const response = await post({
    model: MODEL,
    messages: [
      { role: "user", content: "My name is Ada. Remember it." },
      { role: "assistant", content: "Noted, Ada." },
      { role: "user", content: "What is my name? Answer with one word." },
    ],
    max_completion_tokens: 24,
  });
  assert(response.status === 200, `status ${response.status}`);
  const body = await jsonOf(response);
  const content: string = body.choices?.[0]?.message?.content ?? "";
  assert(/ada/i.test(content), `content: ${JSON.stringify(content)}`);
  return `"${content.trim()}"`;
});

await check("caller system instructions", async () => {
  const response = await post({
    model: MODEL,
    messages: [
      { role: "system", content: "Always answer in uppercase letters." },
      { role: "user", content: "Say hello." },
    ],
    max_completion_tokens: 256,
  });
  assert(response.status === 200, `status ${response.status}`);
  const body = await jsonOf(response);
  const content: string = body.choices?.[0]?.message?.content ?? "";
  assert(content.trim().length > 0, "empty answer");
  assert(content === content.toUpperCase(), `not uppercase: ${JSON.stringify(content)}`);
  return `"${content.trim()}"`;
});

await check("reasoning channel", async () => {
  const response = await post({
    model: MODEL,
    messages: [{ role: "user", content: "What is 17 * 23? Think briefly, then answer with the number only." }],
    stream: true,
    stream_options: { include_usage: true },
    max_completion_tokens: 768,
  });
  assert(response.status === 200, `status ${response.status}`);

  const raw = await response.text();
  const frames = raw
    .split("\n\n")
    .map((block) => block.trim())
    .filter((block) => block.startsWith("data: ") && block !== "data: [DONE]")
    .map((block) => JSON.parse(block.slice(6)) as {
      choices?: Array<{ delta?: { content?: string; reasoning_content?: string } }>;
      usage?: { completion_tokens_details?: { reasoning_tokens?: number } };
    });

  const reasoning = frames.map((f) => f.choices?.[0]?.delta?.reasoning_content ?? "").join("");
  const content = frames.map((f) => f.choices?.[0]?.delta?.content ?? "").join("");
  const reasoningTokens = frames.find((f) => f.usage)?.usage?.completion_tokens_details?.reasoning_tokens ?? 0;
  assert(content.includes("391"), `answer: ${JSON.stringify(content)}`);
  if (reasoningTokens > 0) assert(reasoning.length > 0, "reasoning tokens billed but no reasoning_content streamed");
  return `reasoning ${reasoning.length} chars · answer "${content.trim()}"`;
});

await check("second model", async () => {
  const response = await post({
    model: "glm-5.3-flash-free",
    messages: [{ role: "user", content: "Reply with exactly: GLM_OK" }],
    max_completion_tokens: 32,
  });
  assert(response.status === 200, `status ${response.status}: ${await response.clone().text()}`);
  const body = await jsonOf(response);
  const content: string = body.choices?.[0]?.message?.content ?? "";
  assert(content.includes("GLM_OK"), `content: ${JSON.stringify(content)}`);
  return `"${content.trim()}"`;
});

await check("unknown model rejected", async () => {
  const response = await post({ model: "does-not-exist", messages: [{ role: "user", content: "hi" }] });
  assert(response.status === 404, `status ${response.status}`);
  return "404 not_found_error";
});

console.log("");
const failed = checks.filter((c) => !c.ok);
const totalMs = checks.reduce((n, c) => n + c.ms, 0);
console.log(`summary: ${checks.length - failed.length}/${checks.length} passed in ${totalMs}ms`);
if (failed.length > 0) {
  console.log("failed:");
  for (const c of failed) console.log(`  - ${c.name}: ${c.detail}`);
}

await server.stop();
process.exit(failed.length === 0 ? 0 : 1);
