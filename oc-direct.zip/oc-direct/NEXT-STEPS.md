# Handoff — state as of 2026-11-13

Source of truth: `oc-direct (1).zip` (extracted to `/content/oc-direct`), plus `session-c701cfc9….md`.
The session left off at "upstream stream consumer and OpenAI mapping"; `src/upstream.ts` and `src/openai.ts`
are complete, so the zip is the finished tree, not a mid-edit one.

## Verified today (local only, zero upstream quota)

| Check | Result |
| --- | --- |
| `tsc --noEmit` (strict + `noUncheckedIndexedAccess`) | clean, exit 0 |
| `bun test` | 52 pass, 0 fail, 140 expects, 6 files |
| boot with `OCD_ALLOW_ANONYMOUS=1` | `/healthz` 200, `/readyz` ready/closed/16 |
| `/v1/models`, `/v1/models/{id}`, unknown id | 200, 200, 404 |
| validation paths | empty body 400, bad JSON 400, missing `model` 400, unknown route 404 |
| `/metrics` | Prometheus text, series with route/status labels |

Not run today, by request (they spend the free-tier daily quota): `test:integration` (12 live calls),
`verify:contract` (6 live calls). Both passed in the previous session per README.

## Environment notes

`bun` was not on PATH in this workspace. Installed ad hoc:

```bash
cd /tmp/opencode && npm install --silent bun@1     # → /tmp/opencode/node_modules/.bin/bun (1.4.4)
```

`/tmp` may not survive to tomorrow; if `which bun` fails, rerun that line. Then:

```bash
cd /content/oc-direct
bun test
bun run typecheck      # note: node_modules/.bin/tsc is a broken shim — use
                       # node node_modules/typescript/lib/tsc.js --noEmit
```

The zipped `node_modules` contains only type stubs (`bun-types`, `@types/bun`, `typescript`,
`undici-types`); no runtime deps are needed, but `bun install` will rebuild the bin shims.

## Tomorrow, cheapest-first

1. `bun install` to repair the bin shims (offline-safe, ~2 packages).
2. `bun run test:integration` — 12 live calls, ~1 min. Confirms the attested contract still holds.
3. Only if step 2 shows drift: `bun run verify:contract` — it reports *which* of the five requirements moved.
4. If contract drifted: the captured assets in `src/assets/` (system prompt 8,605 chars, tool schemas,
   `OCD_TOOLS_MODE=read|full`) are what needs re-capturing; `src/upstream.ts` header set is the second place.
5. Optional polish, no quota: `README.md` "Verification" block, `deploy/*` review, `scripts/loadtest.ts`
   (only run it after the contract is confirmed, since a load test burns quota linearly).

## Guardrails to keep

- `OCD_RETRY_MAX` never applies to 429. Nothing in the code evades a quota reset — that is intentional.
- A public listener without `OCD_KEYS` is an open proxy to your quota; bind loopback, TLS in front.
- Reasoning tokens are billed inside `completion_tokens`; `OCD_REASONING_HEADROOM_TOKENS` is opt-in only.
