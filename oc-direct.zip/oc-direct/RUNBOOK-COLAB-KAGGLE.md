# Run `oc-direct` on Colab or Kaggle — end-to-end

Every step is **one cell, run top to bottom**. Works unchanged on **Google Colab** and
**Kaggle**; the only prerequisite is outbound internet:

- **Colab** — internet is on by default.
- **Kaggle** — *Settings → Internet → On* (phone-verified account).

The notebook (`notebooks/oc-direct.ipynb`) contains exactly these cells; this file is the
copy-paste version and the reference. Total time: ~2 minutes; the only quota you spend is
the single completion in cell 7.

---

## Cell 0 — what this does

Downloads the release zip, installs Bun if missing, writes a key-protected `.env`, starts
the gateway on `127.0.0.1:8787`, and proves the whole chain with one real completion.
Re-running any cell is safe: the zip is re-staged, the server is restarted, `.env` is kept.

---

## Cell 1 — download and stage the zip

```python
import os, shutil, subprocess, urllib.request, zipfile

ZIP_URL = "https://github.com/Subham460/ai-gateway/raw/refs/heads/main/oc-direct.zip"
ZIP     = "/tmp/oc-direct.zip"
WORK    = "/kaggle/working" if os.path.isdir("/kaggle/working") else "/content"
DEST    = os.path.join(WORK, "oc-direct")

if not os.path.exists(ZIP) or os.path.getsize(ZIP) < 10_000:
    urllib.request.urlretrieve(ZIP_URL, ZIP)
print("zip:", os.path.getsize(ZIP), "bytes")

STAGE = "/tmp/ocd-stage"
shutil.rmtree(STAGE, ignore_errors=True)
os.makedirs(STAGE, exist_ok=True)
if shutil.which("unzip"):
    subprocess.run(["unzip", "-q", "-o", ZIP, "-d", STAGE], check=True)
else:
    with zipfile.ZipFile(ZIP) as z:
        z.extractall(STAGE)

root = STAGE if os.path.exists(f"{STAGE}/package.json") else f"{STAGE}/oc-direct"
assert os.path.exists(f"{root}/package.json"), f"unexpected layout: {os.listdir(STAGE)}"

os.makedirs(DEST, exist_ok=True)
for name in os.listdir(root):
    src, dst = f"{root}/{name}", f"{DEST}/{name}"
    if os.path.isdir(src):
        shutil.copytree(src, dst, dirs_exist_ok=True)
    else:
        shutil.copy2(src, dst)
os.chdir(DEST)
print("dest:", DEST, "| entries:", len(os.listdir(DEST)))
print("prompt bytes:", os.path.getsize("src/assets/system-prompt.txt"), "(expect 8605)")
```

Expect `prompt bytes: 8605 (expect 8605)`.

---

## Cell 2 — install Bun (skipped if present)

```python
import os, subprocess

BUN = os.path.expanduser("~/.bun/bin/bun")
if not os.path.exists(BUN):
    subprocess.run("curl -fsSL https://bun.sh/install | bash", shell=True, check=True)
os.environ["PATH"] = os.path.dirname(BUN) + ":" + os.environ["PATH"]
print("bun", subprocess.run(["bun", "--version"], capture_output=True, text=True).stdout.strip())
```

Expect `bun 1.4.x`.

---

## Cell 3 — generate the gateway key and `.env`

```python
import os, secrets

os.chdir(DEST)
if not os.path.exists(".env"):
    key = secrets.token_hex(24)
    with open(".env", "w") as f:
        f.write(f"OCD_KEYS={key}:notebook\nOCD_HOST=127.0.0.1\nOCD_PORT=8787\nOCD_LOG_LEVEL=info\n")
    os.chmod(".env", 0o600)
    with open(".env.key", "w") as f:
        f.write(key)
KEY = open(".env.key").read().strip()
print("gateway key:", KEY[:6] + "…" + KEY[-4:], "(full value in .env.key)")
```

Loopback + key means nothing is exposed. Put this key in any OpenAI client as `api_key`.

---

## Cell 4 — start the server

```python
import os, subprocess, time

os.chdir(DEST)
os.environ["PATH"] = os.path.expanduser("~/.bun/bin") + ":" + os.environ["PATH"]

subprocess.run(["pkill", "-f", "src/server.ts"], capture_output=True)   # idempotent restart
time.sleep(1)
log = open("/tmp/ocd.log", "w")
proc = subprocess.Popen(["bash", "run.sh"], cwd=DEST,
                        stdout=log, stderr=subprocess.STDOUT, start_new_session=True)

code = "000"
for _ in range(30):
    time.sleep(1)
    code = subprocess.run(["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
                           "http://127.0.0.1:8787/healthz"], capture_output=True, text=True).stdout
    if code == "200":
        break
print("healthz:", code, "| pid:", proc.pid)
print(open("/tmp/ocd.log").readline()[:400])
```

Expect `healthz: 200` and a `listening` line that now includes a **per-install
`projectId`** and `projectIdSource` (`derived` on first boot, `state` afterwards).

---

## Cell 5 — offline tests (no network, no quota)

```python
import subprocess
print(subprocess.run(["bun", "test"], cwd=DEST, capture_output=True, text=True).stdout[-500:])
```

Expect `60+ pass / 0 fail`.

---

## Cell 6 — end-to-end smoke test

```python
import subprocess
print(subprocess.run(["bash", "scripts/smoke.sh"], cwd=DEST,
                     capture_output=True, text=True).stdout[-900:])
```

Checks reachability, that unauthenticated calls are rejected, the catalog, readiness, and
one real completion. Expect `all checks passed` and `"content":"ok"` (case-insensitive).

---

## Cell 7 — streaming from Python

```python
import json, requests

KEY = open(f"{DEST}/.env.key").read().strip()
r = requests.post(
    "http://127.0.0.1:8787/v1/chat/completions",
    headers={"authorization": f"Bearer {KEY}"},
    json={"model": "deepseek-v4.1-flash-free",
          "messages": [{"role": "user", "content": "count to five"}],
          "stream": True},
    stream=True, timeout=180,
)
r.raise_for_status()
for line in r.iter_lines(decode_unicode=True):
    if not line or not line.startswith("data: "):
        continue
    data = line[6:]
    if data == "[DONE]":
        break
    delta = json.loads(data)["choices"][0]["delta"]
    print(delta.get("reasoning_content") or delta.get("content") or "", end="")
```

Reasoning models stream hidden `reasoning_content` first (default `OCD_REASONING_MODE=separate`).

---

## Cell 8 — use the official SDK (optional)

```python
import subprocess, sys
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "openai"], check=True)

from openai import OpenAI
client = OpenAI(base_url="http://127.0.0.1:8787/v1",
                api_key=open(f"{DEST}/.env.key").read().strip())
r = client.chat.completions.create(
    model="deepseek-v4.1-flash-free",
    messages=[{"role": "user", "content": "one sentence about tide pools"}],
)
print(r.choices[0].message.content)
print(r.usage)
```

---

## Cell 9 — contract check (optional, ~6 live calls)

```python
import subprocess
print(subprocess.run(["bun", "run", "verify:contract"], cwd=DEST,
                     capture_output=True, text=True).stdout[-800:])
```

Expect `contract unchanged`. A `DRIFT` line names which attested element moved.

---

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| `HTTPError 404` on download | the zip is not pushed to that branch yet, or the repo is private |
| `unexpected layout` | re-run cell 1; the archive must contain `oc-direct/` or `package.json` at its root |
| `bun: command not found` | re-run cell 2 — `PATH` is per kernel and lost on restart |
| `Could not resolve host` | Kaggle internet toggle is off / Colab runtime has no network |
| `healthz: 000` | server died; print `/tmp/ocd.log` (cell 4 already shows the first line) |
| `401` from smoke test | `.env` and `.env.key` disagree — delete both and re-run cell 3 |
| `429 FreeUsageLimitError` | upstream throttle; the gateway retries briefly, then reports it. Re-run in a minute, or `bun run verify:contract` |
| empty content + `finish_reason: length` | reasoning ate the budget — raise `max_tokens` |
| server gone after a restart | re-run cells 2 → 4 (Colab/Kaggle recycle `~/.bun` and `/tmp`) |

## Platform facts

- **Colab:** `/content` is wiped when the runtime is recycled; `~/.bun` and `/tmp` too.
  Notebooks are shareable — `.env.key` lives only in the runtime, not in the notebook.
- **Kaggle:** `/kaggle/working` survives only with *Save Version*; no inbound ports, ~12 h
  session cap. Use *Add-ons → Secrets* for a long-lived key instead of cell 3.
- Either way this is a **demo runner**. For a host, use `deploy/docker-compose.yml` behind
  Caddy; see `PRODUCTION.md`.
