import type { LogLevel } from "./config.ts";

const ORDER: Record<LogLevel, number> = { debug: 10, info: 20, warn: 30, error: 40 };

export type Fields = Record<string, unknown>;

export interface Logger {
  debug(msg: string, fields?: Fields): void;
  info(msg: string, fields?: Fields): void;
  warn(msg: string, fields?: Fields): void;
  error(msg: string, fields?: Fields): void;
  child(fields: Fields): Logger;
}

const SECRET_KEYS = /authorization|api[-_]?key|secret|token/i;

function redact(fields: Fields): Fields {
  const out: Fields = {};
  for (const [k, v] of Object.entries(fields)) {
    if (SECRET_KEYS.test(k)) out[k] = "[redacted]";
    else if (k === "prompt" || k === "messages") out[k] = "[redacted]";
    else out[k] = v;
  }
  return out;
}

export function createLogger(level: LogLevel, base: Fields = {}): Logger {
  const threshold = ORDER[level];

  const emit = (lvl: LogLevel, msg: string, fields?: Fields) => {
    if (ORDER[lvl] < threshold) return;
    const record = {
      ts: new Date().toISOString(),
      level: lvl,
      msg,
      ...redact(base),
      ...(fields ? redact(fields) : {}),
    };
    const line = JSON.stringify(record);
    if (lvl === "error" || lvl === "warn") process.stderr.write(line + "\n");
    else process.stdout.write(line + "\n");
  };

  const logger: Logger = {
    debug: (m, f) => emit("debug", m, f),
    info: (m, f) => emit("info", m, f),
    warn: (m, f) => emit("warn", m, f),
    error: (m, f) => emit("error", m, f),
    child: (fields) => createLogger(level, { ...base, ...fields }),
  };
  return logger;
}
