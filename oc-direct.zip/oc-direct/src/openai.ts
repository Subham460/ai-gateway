import type { ToolCall, Usage } from "./types.ts";

export function newCompletionId(): string {
  return `chatcmpl-${crypto.randomUUID().replace(/-/g, "")}`;
}

export interface ChunkDelta {
  role?: "assistant";
  content?: string;
  /** Hidden thinking, verified against the live endpoint and passed through. */
  reasoning_content?: string;
  tool_calls?: ToolCall[];
}

export function chunkPayload(
  id: string,
  created: number,
  model: string,
  delta: ChunkDelta,
  finishReason: string | null = null,
): Record<string, unknown> {
  return {
    id,
    object: "chat.completion.chunk",
    created,
    model,
    choices: [{ index: 0, delta, finish_reason: finishReason }],
  };
}

export function usageChunk(id: string, created: number, model: string, usage: Usage): Record<string, unknown> {
  return { id, object: "chat.completion.chunk", created, model, choices: [], usage };
}

export function completionPayload(
  id: string,
  created: number,
  model: string,
  result: {
    text: string;
    reasoning?: string;
    finishReason: string;
    usage: Usage | null;
    toolCalls: ToolCall[];
  },
): Record<string, unknown> {
  return {
    id,
    object: "chat.completion",
    created,
    model,
    choices: [
      {
        index: 0,
        message: {
          role: "assistant",
          content: result.toolCalls.length > 0 && result.text.length === 0 ? null : result.text,
          ...(result.reasoning ? { reasoning_content: result.reasoning } : {}),
          ...(result.toolCalls.length > 0 ? { tool_calls: result.toolCalls } : {}),
        },
        finish_reason: result.finishReason,
      },
    ],
    usage: result.usage ?? { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 },
  };
}

export function sseFrame(payload: unknown): Uint8Array {
  return new TextEncoder().encode(`data: ${JSON.stringify(payload)}\n\n`);
}

export const SSE_DONE = new TextEncoder().encode("data: [DONE]\n\n");
