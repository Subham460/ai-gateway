/**
 * Session identifiers.
 *
 * The free-tier gateway validates the shape and freshness of the session id
 * carried in `x-opencode-session` / `x-opencode-session-id`. A random id is
 * rejected with `429 FreeUsageLimitError`; an id produced by this exact
 * algorithm is accepted.
 *
 * Reconstructed from the OpenCode 2.2.7 bundle (`Session.ID.create`):
 *
 *   prefix = 6 bytes of  ~(Date.now() * 4096 + counter)
 *   suffix = 14 characters of base62 from crypto random bytes
 *
 * The counter resets whenever the millisecond changes, so multiple ids minted
 * in the same millisecond stay ordered.
 */

const ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
const SUFFIX_LENGTH = 14; // total id length after `ses_` is 26 (12 hex + 14 base62)
const HEX_LENGTH = 12;

let lastMs = 0;
let counter = 0;

/** Generates a valid `ses_...` identifier. `now` is injectable for tests. */
export function sessionID(now: number = Date.now()): string {
  if (now !== lastMs) {
    lastMs = now;
    counter = 0;
  }
  counter += 1;

  const value = ~(BigInt(now) * 4096n + BigInt(counter));
  let hex = "";
  for (let i = 0; i < 6; i++) {
    const byte = Number((value >> BigInt(40 - 8 * i)) & 0xffn);
    hex += byte.toString(16).padStart(2, "0");
  }

  const random = crypto.getRandomValues(new Uint8Array(SUFFIX_LENGTH));
  let suffix = "";
  for (const byte of random) suffix += ALPHABET[byte % 62];

  return `ses_${hex}${suffix}`;
}

/** True when `id` has the structural shape the gateway expects. */
export function isSessionID(id: string): boolean {
  return /^ses_[0-9a-f]{12}[0-9A-Za-z]{14}$/.test(id);
}

/**
 * Recovers the low 36 bits of the creation timestamp (the part not truncated by
 * the 48-bit prefix) plus the in-millisecond counter. Used by tests and by the
 * `x-ocd-session-ts` debug header; not required for operation.
 */
export function decodeSessionID(id: string): { msLow36: number; counter: number } | null {
  if (!isSessionID(id)) return null;
  const hex = id.slice(4, 4 + HEX_LENGTH);
  const inverted = BigInt(`0x${hex}`);
  const value = (~inverted) & 0xffffffffffffn; // back to 48 bits
  return {
    msLow36: Number(value >> 12n),
    counter: Number(value & 0xfffn),
  };
}
