/**
 * Request assembly for the free-tier wire protocol.
 *
 * The upstream attests the request shape, not just the transport. Verified
 * against the live endpoint:
 *
 *   canonical system prompt   required (a short prompt -> 429)
 *   `read` tool               required (no tools, or a non-read-only set -> 429)
 *   `stream: true`            required (`stream:false` -> 429)
 *   valid session id header   required (random ids -> 429)
 *
 * User/assistant history, an appended "# User Instructions" block,
 * `tool_choice`, `max_completion_tokens`, and the model id are all accepted.
 */

import { BadRequestError } from "./errors.ts";
import type { ChatMessage, ChatRequest } from "./types.ts";
import type { ModelInfo } from "./catalog.ts";
import type { ToolChoice, ToolsMode } from "./config.ts";

const ASSETS = `${import.meta.dir}/assets`;

export const CANONICAL_SYSTEM_PROMPT = (await Bun.file(`${ASSETS}/system-prompt.txt`).text()).trimEnd();
export const READ_TOOL = (await Bun.file(`${ASSETS}/tool-read.json`).json()) as unknown[];
export const FULL_TOOLS = (await Bun.file(`${ASSETS}/tools-full.json`).json()) as unknown[];
export const MAX_COMPLETION_TOKENS = 32_000;

/**
 * Appended when tools are declared as unavailable. Models that were told about
 * tools by the caller's system text otherwise emit tool-call markup as plain
 * content (DeepSeek: `<|DSML| invoke …>`), which no client can execute and which
 * the user sees as garbage.
 */
export const NO_TOOL_DIRECTIVE =
  "# Tool Availability\nNo tools are available for this request. Do not emit tool-call syntax, " +
  "function-call markup, XML tags (including <|DSML|>), or JSON tool invocations. Answer in plain prose.";

export interface BuildOptions {
  toolsMode: ToolsMode;
  toolChoice: ToolChoice;
  defaultMaxTokens: number;
  /** Append `NO_TOOL_DIRECTIVE` whenever tools are suppressed. Defaults to on. */
  chatGuard?: boolean;
  /**
   * Tokens added to the requested completion budget to cover hidden reasoning.
   * Reasoning tokens are charged against `max_completion_tokens` upstream, so a
   * request for 32 tokens can otherwise come back empty after 32 thinking tokens.
   */
  reasoningHeadroomTokens?: number;
}

export interface BuiltRequest {
  body: string;
  /** Number of characters in the assembled prompt, for logging/estimating. */
  promptChars: number;
  maxTokens: number;
}

function contentToText(content: ChatMessage["content"]): string {
  if (content == null) return "";
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  const parts: string[] = [];
  for (const part of content) {
    if (!part || typeof part !== "object") continue;
    if ((part.type === "text" || part.type === "input_text") && typeof part.text === "string") {
      parts.push(part.text);
    } else if (part.type === "image_url" || part.type === "input_image") {
      parts.push("[image omitted: this gateway is text-only]");
    }
  }
  return parts.join("\n");
}

function clampTokens(requested: number | undefined, model: ModelInfo, fallback: number): number {
  const value = Math.floor(requested ?? fallback);
  if (!Number.isFinite(value) || value < 1) return Math.min(fallback, model.maxOutputTokens);
  return Math.min(value, model.maxOutputTokens, MAX_COMPLETION_TOKENS);
}

export function buildUpstreamBody(
  request: ChatRequest,
  model: ModelInfo,
  options: BuildOptions,
): BuiltRequest {
  if (!Array.isArray(request.messages) || request.messages.length === 0) {
    throw new BadRequestError("`messages` must be a non-empty array", "messages");
  }

  const systemBlocks: string[] = [];
  const conversation: ChatMessage[] = [];

  for (const message of request.messages) {
    if (!message || typeof message.role !== "string") {
      throw new BadRequestError("every message needs a string `role`", "messages");
    }
    const text = contentToText(message.content);

    switch (message.role) {
      case "system":
      case "developer":
        if (text.trim()) systemBlocks.push(text.trim());
        break;
      case "user":
        if (text.trim()) conversation.push({ role: "user", content: text });
        break;
      case "assistant": {
        const hasToolCalls = Array.isArray(message.tool_calls) && message.tool_calls.length > 0;
        if (text.trim() || hasToolCalls) {
          conversation.push({ role: "assistant", content: text });
        }
        break;
      }
      case "tool":
      case "function": {
        const label = message.name ? `Tool result (${message.name})` : "Tool result";
        if (text.trim()) conversation.push({ role: "user", content: `${label}:\n${text}` });
        break;
      }
      default:
        throw new BadRequestError(`unsupported message role: ${message.role}`, "messages");
    }
  }

  if (!conversation.some((m) => m.role === "user")) {
    throw new BadRequestError("`messages` must contain at least one non-empty user message", "messages");
  }

  let system = CANONICAL_SYSTEM_PROMPT;
  if (systemBlocks.length > 0) {
    system += `\n\n# User Instructions\n${systemBlocks.join("\n\n")}`;
  }
  if (options.toolChoice === "none" && options.chatGuard !== false) {
    system += `\n\n${NO_TOOL_DIRECTIVE}`;
  }

  const requested = clampTokens(
    request.max_completion_tokens ?? request.max_tokens,
    model,
    options.defaultMaxTokens,
  );
  const ceiling = Math.min(MAX_COMPLETION_TOKENS, model.maxOutputTokens);
  const maxTokens = Math.min(ceiling, requested + Math.max(0, options.reasoningHeadroomTokens ?? 0));

  const tools = options.toolsMode === "full" ? FULL_TOOLS : READ_TOOL;
  const body = {
    model: model.id,
    messages: [{ role: "system", content: system }, ...conversation],
    tools,
    tool_choice: options.toolChoice,
    stream: true,
    stream_options: { include_usage: true },
    max_completion_tokens: maxTokens,
  };

  return {
    body: JSON.stringify(body),
    promptChars: system.length + conversation.reduce((n, m) => n + String(m.content).length, 0),
    maxTokens,
  };
}
