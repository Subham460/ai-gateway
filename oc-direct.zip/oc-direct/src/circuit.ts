/** Three-state circuit breaker guarding the upstream. */
export type CircuitState = "closed" | "open" | "half-open";

export class CircuitBreaker {
  private failures = 0;
  private openedAt = 0;
  private state: CircuitState = "closed";
  private probing = false;

  constructor(
    private readonly threshold: number,
    private readonly cooldownMs: number,
  ) {}

  get current(): CircuitState {
    if (this.state === "open" && Date.now() - this.openedAt >= this.cooldownMs) {
      this.state = "half-open";
      this.probing = false;
    }
    return this.state;
  }

  allow(): boolean {
    const state = this.current;
    if (state === "closed") return true;
    if (state === "open") return false;
    if (this.probing) return false; // one probe at a time
    this.probing = true;
    return true;
  }

  success(): void {
    this.failures = 0;
    this.state = "closed";
    this.probing = false;
  }

  failure(): void {
    this.failures += 1;
    this.probing = false;
    if (this.state === "half-open" || this.failures >= this.threshold) {
      this.state = "open";
      this.openedAt = Date.now();
    }
  }

  get failureCount(): number {
    return this.failures;
  }
}
