/**
 * Configuration loading and validation.
 *
 * Every knob is environment-driven so the same image runs in dev, systemd, and
 * containers. Invalid configuration fails fast at boot rather than at the first
 * request.
 */

export type LogLevel = "debug" | "info" | "warn" | "error";
export type ToolsMode = "read" | "full";
export type ToolChoice = "none" | "auto";
/**
 * What to do with upstream `reasoning_content` (hidden thinking on hybrid models).
 *
 * - `separate` — emit it as `delta.reasoning_content` / `message.reasoning_content`
 *   (DeepSeek/OpenRouter convention); `content` stays clean.
 * - `content`  — concatenate it ahead of the visible answer.
 * - `drop`     — discard it, as if the model had no reasoning channel.
 */
export type ReasoningMode = "separate" | "content" | "drop";

export interface ApiKey {
  /** Stable identifier used in logs and metrics. */
  id: string;
  /** Bearer secret. Never logged. */
  secret: string;
}

export interface Config {
  host: string;
  port: number;
  upstreamUrl: string;
  projectId: string;
  userAgent: string;
  clientName: string;
  apiKeys: ApiKey[];
  allowAnonymous: boolean;
  rateLimitRpm: number;
  maxConcurrency: number;
  queueTimeoutMs: number;
  upstreamTimeoutMs: number;
  upstreamIdleTimeoutMs: number;
  retryMax: number;
  circuitThreshold: number;
  circuitCooldownMs: number;
  toolsMode: ToolsMode;
  toolChoice: ToolChoice;
  /**
   * When tools are suppressed, append a directive that forbids the model from
   * emitting tool-call markup as text. No declared tools means a model that was
   * told about them (by the caller's system text) will otherwise invent XML or
   * DSML invocations that no client can execute.
   */
  chatGuard: boolean;
  reasoningMode: ReasoningMode;
  /** Extra completion-token budget so reasoning cannot starve a small `max_tokens`. */
  reasoningHeadroomTokens: number;
  defaultMaxTokens: number;
  maxBodyBytes: number;
  logLevel: LogLevel;
  logPrompts: boolean;
  metricsPublic: boolean;
  allowAnyModel: boolean;
}

const LOG_LEVELS: LogLevel[] = ["debug", "info", "warn", "error"];

function str(env: Record<string, string | undefined>, name: string, fallback: string): string {
  const v = env[name];
  return v === undefined || v === "" ? fallback : v;
}

function int(
  env: Record<string, string | undefined>,
  name: string,
  fallback: number,
  { min = 0, max = Number.MAX_SAFE_INTEGER }: { min?: number; max?: number } = {},
): number {
  const raw = env[name];
  if (raw === undefined || raw === "") return fallback;
  const n = Number(raw);
  if (!Number.isFinite(n) || !Number.isInteger(n) || n < min || n > max) {
    throw new Error(`invalid ${name}=${raw}: expected integer in [${min}, ${max}]`);
  }
  return n;
}

function bool(env: Record<string, string | undefined>, name: string, fallback: boolean): boolean {
  const raw = env[name];
  if (raw === undefined || raw === "") return fallback;
  if (["1", "true", "yes", "on"].includes(raw.toLowerCase())) return true;
  if (["0", "false", "no", "off"].includes(raw.toLowerCase())) return false;
  throw new Error(`invalid ${name}=${raw}: expected boolean`);
}

/**
 * Accepts `secret` or `secret:name` entries, comma separated.
 * Example: `OCD_KEYS="s3cr3t:alice,an0ther:bob"`.
 */
export function parseKeys(raw: string): ApiKey[] {
  const keys: ApiKey[] = [];
  const seen = new Set<string>();
  for (const entry of raw.split(",").map((s) => s.trim()).filter(Boolean)) {
    const idx = entry.lastIndexOf(":");
    const secret = idx > 0 ? entry.slice(0, idx) : entry;
    const name = idx > 0 ? entry.slice(idx + 1) : `key-${keys.length + 1}`;
    if (secret.length < 8) throw new Error("API keys must be at least 8 characters");
    if (seen.has(secret)) throw new Error("duplicate API key in OCD_KEYS");
    seen.add(secret);
    keys.push({ id: name, secret });
  }
  return keys;
}

export function loadConfig(env: Record<string, string | undefined> = process.env): Config {
  const apiKeys = parseKeys(str(env, "OCD_KEYS", ""));
  const allowAnonymous = bool(env, "OCD_ALLOW_ANONYMOUS", false);
  if (apiKeys.length === 0 && !allowAnonymous) {
    throw new Error(
      "no API keys configured. Set OCD_KEYS='secret:name,...' or OCD_ALLOW_ANONYMOUS=1 for loopback-only use.",
    );
  }

  const logLevel = str(env, "OCD_LOG_LEVEL", "info") as LogLevel;
  if (!LOG_LEVELS.includes(logLevel)) {
    throw new Error(`invalid OCD_LOG_LEVEL=${logLevel}: expected ${LOG_LEVELS.join("|")}`);
  }

  const toolsMode = str(env, "OCD_TOOLS_MODE", "read") as ToolsMode;
  if (toolsMode !== "read" && toolsMode !== "full") {
    throw new Error("invalid OCD_TOOLS_MODE: expected read|full");
  }

  const toolChoice = str(env, "OCD_TOOL_CHOICE", "none") as ToolChoice;
  if (toolChoice !== "none" && toolChoice !== "auto") {
    throw new Error("invalid OCD_TOOL_CHOICE: expected none|auto");
  }

  const reasoningMode = str(env, "OCD_REASONING_MODE", "separate") as ReasoningMode;
  if (reasoningMode !== "separate" && reasoningMode !== "content" && reasoningMode !== "drop") {
    throw new Error("invalid OCD_REASONING_MODE: expected separate|content|drop");
  }

  const host = str(env, "OCD_HOST", "127.0.0.1");
  if (!allowAnonymous && (host === "0.0.0.0" || host === "::")) {
    // Allowed, but the operator must have deliberately configured keys.
  }

  return {
    host,
    port: int(env, "OCD_PORT", 8787, { min: 0, max: 65535 }),
    upstreamUrl: str(env, "OCD_UPSTREAM_URL", "https://opencode.ai/inference/openai/v1").replace(/\/+$/, ""),
    projectId: str(env, "OCD_PROJECT_ID", "470c8549ef01a2a9d3c85b22965766cefc874134"),
    userAgent: str(env, "OCD_USER_AGENT", "opencode/latest/2.2.7/cli"),
    clientName: str(env, "OCD_CLIENT_NAME", "cli"),
    apiKeys,
    allowAnonymous,
    rateLimitRpm: int(env, "OCD_RATE_LIMIT_RPM", 120, { min: 0 }),
    maxConcurrency: int(env, "OCD_MAX_CONCURRENCY", 16, { min: 1, max: 4096 }),
    queueTimeoutMs: int(env, "OCD_QUEUE_TIMEOUT_MS", 30_000, { min: 100 }),
    upstreamTimeoutMs: int(env, "OCD_UPSTREAM_TIMEOUT_MS", 300_000, { min: 1_000 }),
    upstreamIdleTimeoutMs: int(env, "OCD_UPSTREAM_IDLE_TIMEOUT_MS", 120_000, { min: 1_000 }),
    retryMax: int(env, "OCD_RETRY_MAX", 2, { min: 0, max: 5 }),
    circuitThreshold: int(env, "OCD_CIRCUIT_THRESHOLD", 6, { min: 1 }),
    circuitCooldownMs: int(env, "OCD_CIRCUIT_COOLDOWN_MS", 30_000, { min: 100 }),
    toolsMode,
    toolChoice,
    chatGuard: bool(env, "OCD_CHAT_GUARD", true),
    reasoningMode,
    reasoningHeadroomTokens: int(env, "OCD_REASONING_HEADROOM_TOKENS", 0, { min: 0, max: 16_000 }),
    defaultMaxTokens: int(env, "OCD_DEFAULT_MAX_TOKENS", 32_000, { min: 1 }),
    maxBodyBytes: int(env, "OCD_MAX_BODY_BYTES", 1_048_576, { min: 1024 }),
    logLevel,
    logPrompts: bool(env, "OCD_LOG_PROMPTS", false),
    metricsPublic: bool(env, "OCD_METRICS_PUBLIC", false),
    allowAnyModel: bool(env, "OCD_ALLOW_ANY_MODEL", false),
  };
}
