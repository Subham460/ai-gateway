/**
 * Server-Sent Events framing.
 *
 * The upstream emits `text/event-stream` with `data:` lines separated by blank
 * lines. Chunk boundaries are arbitrary, so the parser buffers until a full
 * event block is available. Multi-line `data:` fields are joined with `\n`
 * per the SSE spec.
 */

/** Extracts the `data` payload of one event block, or `null` if it has none. */
export function extractData(block: string): string | null {
  const parts: string[] = [];
  for (const line of block.split(/\r?\n/)) {
    if (!line.startsWith("data:")) continue;
    const value = line.slice(5);
    parts.push(value.startsWith(" ") ? value.slice(1) : value);
  }
  if (parts.length === 0) return null;
  const payload = parts.join("\n");
  return payload.trim().length === 0 ? null : payload;
}

export class SSEParser {
  private buffer = "";

  /** Feeds a decoded stream fragment and returns all complete event payloads. */
  push(text: string): string[] {
    this.buffer += text;
    const out: string[] = [];
    let index: number;
    while ((index = this.buffer.search(/\r?\n\r?\n/)) !== -1) {
      const match = this.buffer.slice(index).match(/^\r?\n\r?\n/)!;
      const block = this.buffer.slice(0, index);
      this.buffer = this.buffer.slice(index + match[0].length);
      const data = extractData(block);
      if (data !== null) out.push(data);
    }
    return out;
  }

  /** Returns any trailing event that was not terminated by a blank line. */
  flush(): string[] {
    const rest = this.buffer;
    this.buffer = "";
    if (!rest) return [];
    const data = extractData(rest);
    return data === null ? [] : [data];
  }
}
