import type { Config } from "./config.ts";
import { CircuitBreaker } from "./circuit.ts";
import {
  ServiceUnavailableError,
  UpstreamHttpError,
  UpstreamNetworkError,
  UpstreamTimeoutError,
} from "./errors.ts";
import { sessionID } from "./ids.ts";
import type { Logger } from "./logger.ts";
import type { Metrics } from "./metrics.ts";
import { SSEParser } from "./sse.ts";
import type { ToolCall, UpstreamDelta, Usage } from "./types.ts";

export interface CompleteOptions {
  /** Pre-serialized upstream JSON body. */
  body: string;
  signal?: AbortSignal;
  requestId: string;
  onContent?: (delta: string) => void;
  onReasoning?: (delta: string) => void;
  onToolCall?: (delta: ToolCall) => void;
}

export interface CompleteResult {
  text: string;
  /** Concatenated hidden reasoning, when the model produced any. */
  reasoning: string;
  finishReason: string;
  usage: Usage | null;
  toolCalls: ToolCall[];
  attempts: number;
  durationMs: number;
}

export interface OpenStream {
  /** Resolves when the body has been fully consumed. */
  result: Promise<CompleteResult>;
  /** Aborts the request and the reader. */
  abort: () => void;
}

const RETRYABLE_STATUS = new Set([408, 429, 500, 502, 503, 504]);
const MAX_BACKOFF_MS = 4_000;

/** `429` is a quota signal, not an outage: it must not trip the breaker. */
function isQuotaError(error: unknown): boolean {
  return error instanceof UpstreamHttpError && error.upstreamStatus === 429;
}

function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(signal.reason);
    const onAbort = () => {
      clearTimeout(timer);
      reject(signal?.reason);
    };
    const timer = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

/** Extracts the human message and retry hint from an upstream error body. */
export function parseUpstreamError(
  status: number,
  body: string,
  retryAfterHeader: string | null,
): UpstreamHttpError {
  let message = `upstream returned ${status}`;
  try {
    const parsed = JSON.parse(body) as { error?: { message?: string }; message?: string };
    message = parsed.error?.message ?? parsed.message ?? message;
  } catch {
    if (body.trim()) message = body.slice(0, 500);
  }
  let retryAfterMs: number | null = null;
  if (retryAfterHeader) {
    const seconds = Number(retryAfterHeader);
    if (Number.isFinite(seconds)) retryAfterMs = seconds * 1000;
    else {
      const date = Date.parse(retryAfterHeader);
      if (Number.isFinite(date)) retryAfterMs = Math.max(0, date - Date.now());
    }
  }
  return new UpstreamHttpError(status, message, retryAfterMs);
}

export class UpstreamClient {
  private readonly circuit: CircuitBreaker;

  constructor(
    private readonly config: Config,
    private readonly metrics: Metrics,
    private readonly logger: Logger,
  ) {
    this.circuit = new CircuitBreaker(config.circuitThreshold, config.circuitCooldownMs);
    metrics.describe("ocd_upstream_requests_total", "Upstream HTTP attempts by final status");
    metrics.describe("ocd_upstream_duration_ms", "Upstream request duration in milliseconds");
    metrics.describe("ocd_upstream_retries_total", "Retried upstream attempts");
    metrics.describe("ocd_upstream_circuit_state", "Circuit breaker state (0 closed, 1 half-open, 2 open)");
  }

  get circuitState(): string {
    return this.circuit.current;
  }

  available(): boolean {
    return this.circuit.current !== "open";
  }

  /**
   * Opens the upstream request. Resolves only after the upstream accepted the
   * request (2xx), so callers can still send an HTTP error status when it did
   * not. The body is consumed in the background; `result` settles when done.
   */
  async open(options: CompleteOptions): Promise<OpenStream> {
    const started = Date.now();
    /** `retry-after` from the most recent failure, used to shape the next wait. */
    let retryAfterMs: number | null = null;

    for (let attempt = 0; attempt <= this.config.retryMax; attempt++) {
      if (attempt > 0) {
        this.metrics.inc("ocd_upstream_retries_total");
        // Never honour an upstream hint literally: the free tier reports
        // windows of hours that clear in seconds. Clamp it, and fall back to
        // exponential backoff when the response carried no hint.
        const hinted =
          retryAfterMs === null
            ? null
            : Math.min(Math.max(retryAfterMs, 0), this.config.retryAfterCapMs);
        const backoff = hinted ?? Math.min(MAX_BACKOFF_MS, 250 * 2 ** (attempt - 1));
        const jitter = Math.floor(Math.random() * 100);
        this.logger.warn("retrying upstream", {
          requestId: options.requestId,
          attempt,
          backoff: backoff + jitter,
          upstreamHintMs: retryAfterMs,
        });
        await sleep(backoff + jitter, options.signal);
      }

      if (!this.circuit.allow()) {
        throw new ServiceUnavailableError("upstream circuit is open", this.config.circuitCooldownMs);
      }

      try {
        const stream = await this.openOnce(options, attempt, started);
        this.circuit.success();
        return stream;
      } catch (error) {
        retryAfterMs = error instanceof UpstreamHttpError ? error.retryAfterMs : null;
        const retryable =
          error instanceof UpstreamNetworkError ||
          (error instanceof UpstreamHttpError && RETRYABLE_STATUS.has(error.upstreamStatus));
        if (!retryable || attempt === this.config.retryMax) {
          if (error instanceof UpstreamHttpError || error instanceof UpstreamNetworkError) {
            if (!isQuotaError(error)) this.circuit.failure();
            this.metrics.inc("ocd_upstream_requests_total", {
              status: error instanceof UpstreamHttpError ? String(error.upstreamStatus) : "error",
            });
          }
          this.updateCircuitGauge();
          throw error;
        }
        this.logger.warn("upstream attempt failed", {
          requestId: options.requestId,
          attempt,
          error: error.message,
        });
      }
    }
    throw new UpstreamNetworkError("upstream retries exhausted");
  }

  /** Convenience wrapper for non-streaming callers. */
  async complete(options: CompleteOptions): Promise<CompleteResult> {
    const stream = await this.open(options);
    return stream.result;
  }

  private updateCircuitGauge(): void {
    const state = this.circuit.current;
    this.metrics.set("ocd_upstream_circuit_state", state === "open" ? 2 : state === "half-open" ? 1 : 0);
  }

  private async openOnce(options: CompleteOptions, attempt: number, started: number): Promise<OpenStream> {
    const session = sessionID();
    this.metrics.inc("ocd_sessions_total");
    const headers: Record<string, string> = {
      authorization: "Bearer public",
      "content-type": "application/json",
      "user-agent": this.config.userAgent,
      "x-opencode-client": this.config.clientName,
      "x-opencode-project": this.config.projectId,
      "x-opencode-session-id": session,
      "x-opencode-session": session,
    };

    const controller = new AbortController();
    let timedOut = false;
    const abortFromParent = () => controller.abort(options.signal?.reason);
    if (options.signal) {
      if (options.signal.aborted) throw options.signal.reason;
      options.signal.addEventListener("abort", abortFromParent, { once: true });
    }

    const totalTimer = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, this.config.upstreamTimeoutMs);

    let idleTimer: ReturnType<typeof setTimeout> | null = null;
    const resetIdle = () => {
      if (idleTimer) clearTimeout(idleTimer);
      idleTimer = setTimeout(() => {
        timedOut = true;
        controller.abort();
      }, this.config.upstreamIdleTimeoutMs);
    };
    resetIdle();

    const cleanup = () => {
      clearTimeout(totalTimer);
      if (idleTimer) clearTimeout(idleTimer);
      options.signal?.removeEventListener("abort", abortFromParent);
    };

    let response: Response;
    try {
      response = await fetch(`${this.config.upstreamUrl}/chat/completions`, {
        method: "POST",
        headers,
        body: options.body,
        signal: controller.signal,
      });
    } catch (error) {
      cleanup();
      if (timedOut) throw new UpstreamTimeoutError();
      if (options.signal?.aborted) throw options.signal.reason;
      throw new UpstreamNetworkError((error as Error).message || "network error");
    }

    if (!response.ok) {
      cleanup();
      const text = await response.text().catch(() => "");
      throw parseUpstreamError(response.status, text, response.headers.get("retry-after"));
    }
    if (!response.body) {
      cleanup();
      throw new UpstreamNetworkError("upstream returned an empty body");
    }

    const result = this.consume(response.body, options, {
      cleanup,
      resetIdle,
      timedOut: () => timedOut,
      started,
      attempt,
    });

    return { result, abort: () => controller.abort() };
  }

  private async consume(
    body: ReadableStream<Uint8Array>,
    options: CompleteOptions,
    state: {
      cleanup: () => void;
      resetIdle: () => void;
      timedOut: () => boolean;
      started: number;
      attempt: number;
    },
  ): Promise<CompleteResult> {
    let text = "";
    let reasoning = "";
    const toolCalls: ToolCall[] = [];
    let finishReason = "stop";
    // Held in an object: the only assignment happens inside a closure, and TS's
    // control-flow analysis would otherwise narrow the read site to `null`.
    const captured: { usage: Usage | null } = { usage: null };

    const reader = body.getReader();
    const decoder = new TextDecoder();
    const parser = new SSEParser();
    let done = false;

    /** Parses one SSE payload; returns true when the stream signalled [DONE]. */
    const handlePayload = (payload: string): boolean => {
      if (payload === "[DONE]") return true;

      let chunk: {
        choices?: Array<{
          delta?: UpstreamDelta;
          finish_reason?: string | null;
        }>;
        usage?: Usage;
        error?: { message?: string };
      };
      try {
        chunk = JSON.parse(payload);
      } catch {
        return false;
      }
      if (chunk.error?.message) throw new UpstreamNetworkError(chunk.error.message);

      const choice = chunk.choices?.[0];
      const thought = choice?.delta?.reasoning_content;
      if (typeof thought === "string" && thought.length > 0) {
        reasoning += thought;
        options.onReasoning?.(thought);
      }
      const delta = choice?.delta?.content;
      if (typeof delta === "string" && delta.length > 0) {
        text += delta;
        options.onContent?.(delta);
      }
      if (choice?.delta?.tool_calls) {
        for (const call of choice.delta.tool_calls) {
          toolCalls.push(call);
          options.onToolCall?.(call);
        }
      }
      if (choice?.finish_reason) finishReason = choice.finish_reason;
      if (chunk.usage) {
        captured.usage = {
          prompt_tokens: chunk.usage.prompt_tokens ?? 0,
          completion_tokens: chunk.usage.completion_tokens ?? 0,
          total_tokens: chunk.usage.total_tokens ?? 0,
          ...(chunk.usage.prompt_tokens_details
            ? { prompt_tokens_details: chunk.usage.prompt_tokens_details }
            : {}),
          ...(chunk.usage.completion_tokens_details
            ? { completion_tokens_details: chunk.usage.completion_tokens_details }
            : {}),
        };
      }
      return false;
    };

    try {
      while (!done) {
        const read = await reader.read();
        if (read.done) {
          for (const payload of parser.flush()) {
            if (handlePayload(payload)) break;
          }
          break;
        }
        state.resetIdle();
        for (const payload of parser.push(decoder.decode(read.value, { stream: true }))) {
          if (handlePayload(payload)) {
            done = true;
            break;
          }
        }
      }
    } catch (error) {
      if (state.timedOut()) throw new UpstreamTimeoutError();
      if (options.signal?.aborted) throw options.signal.reason;
      if (error instanceof UpstreamHttpError || error instanceof UpstreamNetworkError) throw error;
      throw new UpstreamNetworkError((error as Error).message || "stream error");
    } finally {
      state.cleanup();
      try {
        await reader.cancel();
      } catch {}
    }

    const durationMs = Date.now() - state.started;
    this.metrics.inc("ocd_upstream_requests_total", { status: "200" });
    this.metrics.observe("ocd_upstream_duration_ms", durationMs);
    this.metrics.set("ocd_upstream_circuit_state", 0);
    const usage = captured.usage;
    if (usage) {
      this.metrics.inc("ocd_tokens_total", { type: "prompt" }, usage.prompt_tokens);
      this.metrics.inc("ocd_tokens_total", { type: "completion" }, usage.completion_tokens);
    }

    return { text, reasoning, finishReason, usage, toolCalls, attempts: state.attempt + 1, durationMs };
  }
}
