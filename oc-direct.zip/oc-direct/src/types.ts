export interface ContentPart {
  type: string;
  text?: string;
  [key: string]: unknown;
}

export interface ToolCall {
  id?: string;
  type?: string;
  index?: number;
  function?: { name?: string; arguments?: string };
}

export interface ChatMessage {
  role: string;
  content?: string | ContentPart[] | null;
  name?: string;
  tool_call_id?: string;
  tool_calls?: ToolCall[];
  [key: string]: unknown;
}

export interface ChatRequest {
  model: string;
  messages: ChatMessage[];
  stream?: boolean;
  stream_options?: { include_usage?: boolean };
  max_tokens?: number;
  max_completion_tokens?: number;
  [key: string]: unknown;
}

export interface Usage {
  prompt_tokens: number;
  completion_tokens: number;
  total_tokens: number;
  prompt_tokens_details?: { cached_tokens?: number };
  completion_tokens_details?: { reasoning_tokens?: number };
}

export interface UpstreamDelta {
  role?: string;
  content?: string | null;
  /** Hidden thinking channel emitted by hybrid/reasoning models. */
  reasoning_content?: string | null;
  tool_calls?: ToolCall[];
}

export interface UpstreamChunk {
  id?: string;
  object?: string;
  created?: number;
  model?: string;
  choices?: Array<{
    index?: number;
    delta?: UpstreamDelta;
    finish_reason?: string | null;
  }>;
  usage?: {
    prompt_tokens?: number;
    completion_tokens?: number;
    total_tokens?: number;
    prompt_tokens_details?: { cached_tokens?: number };
    completion_tokens_details?: { reasoning_tokens?: number };
  };
  error?: { message?: string; type?: string; code?: string };
}
