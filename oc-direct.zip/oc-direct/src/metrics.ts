/**
 * Minimal Prometheus text-format registry: counters, gauges, and histograms.
 * No dependencies, no unbounded label cardinality (callers pass fixed labels).
 */

type Labels = Record<string, string>;

function labelKey(labels?: Labels): string {
  if (!labels) return "";
  const keys = Object.keys(labels).sort();
  if (keys.length === 0) return "";
  return keys.map((k) => `${k}="${String(labels[k]).replace(/["\\\n]/g, "_")}"`).join(",");
}

function series(name: string, labels?: Labels): string {
  const l = labelKey(labels);
  return l ? `${name}{${l}}` : name;
}

const DEFAULT_BUCKETS = [5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10_000, 30_000, 60_000, 120_000];

interface Histogram {
  buckets: number[];
  counts: number[];
  sum: number;
  count: number;
}

export class Metrics {
  private counters = new Map<string, number>();
  private gauges = new Map<string, number>();
  private histograms = new Map<string, Histogram>();
  private help = new Map<string, string>();

  describe(name: string, help: string): void {
    this.help.set(name, help);
  }

  inc(name: string, labels?: Labels, value = 1): void {
    const key = series(name, labels);
    this.counters.set(key, (this.counters.get(key) ?? 0) + value);
  }

  set(name: string, value: number, labels?: Labels): void {
    this.gauges.set(series(name, labels), value);
  }

  observe(name: string, value: number, labels?: Labels): void {
    const key = series(name, labels);
    let h = this.histograms.get(key);
    if (!h) {
      const buckets = [...DEFAULT_BUCKETS];
      h = { buckets, counts: new Array(buckets.length + 1).fill(0), sum: 0, count: 0 };
      this.histograms.set(key, h);
    }
    h.sum += value;
    h.count += 1;
    let i = 0;
    while (i < h.buckets.length && value > h.buckets[i]!) i++;
    h.counts[i]! += 1;
  }

  render(): string {
    const lines: string[] = [];
    const emitted = new Set<string>();

    for (const [key, value] of this.counters) {
      const name = key.split("{")[0]!;
      if (!emitted.has(name)) {
        if (this.help.has(name)) lines.push(`# HELP ${name} ${this.help.get(name)}`, `# TYPE ${name} counter`);
        emitted.add(name);
      }
      lines.push(`${key} ${value}`);
    }

    for (const [key, value] of this.gauges) {
      const name = key.split("{")[0]!;
      if (!emitted.has(name)) {
        if (this.help.has(name)) lines.push(`# HELP ${name} ${this.help.get(name)}`, `# TYPE ${name} gauge`);
        emitted.add(name);
      }
      lines.push(`${key} ${value}`);
    }

    for (const [key, h] of this.histograms) {
      const name = key.split("{")[0]!;
      if (!emitted.has(name)) {
        if (this.help.has(name)) lines.push(`# HELP ${name} ${this.help.get(name)}`, `# TYPE ${name} histogram`);
        emitted.add(name);
      }
      const base = key.includes("{") ? key.slice(0, key.indexOf("{")) : key;
      const labelsPart = key.includes("{") ? key.slice(key.indexOf("{") + 1, -1) : "";
      const withLabels = (le: string) => (labelsPart ? `${base}_bucket{${labelsPart},le="${le}"}` : `${base}_bucket{le="${le}"}`);
      let cumulative = 0;
      for (let i = 0; i < h.buckets.length; i++) {
        cumulative += h.counts[i]!;
        lines.push(`${withLabels(String(h.buckets[i]))} ${cumulative}`);
      }
      cumulative += h.counts[h.buckets.length]!;
      lines.push(`${withLabels("+Inf")} ${cumulative}`);
      lines.push(`${base}_sum${labelsPart ? `{${labelsPart}}` : ""} ${h.sum}`);
      lines.push(`${base}_count${labelsPart ? `{${labelsPart}}` : ""} ${h.count}`);
    }

    return lines.join("\n") + "\n";
  }
}
