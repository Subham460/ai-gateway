/**
 * Per-install project identity.
 *
 * `x-opencode-project` is **not** attested by the free tier: the live endpoint
 * serves any value, including `"abc"`. So this is identity hygiene, not a wire
 * requirement. It matters because the shipped default was a single public id
 * shared by every deployment of this repo — a stable per-install value avoids
 * that, and stays valid if upstream ever scopes usage by project.
 *
 * Resolution order:
 *
 *   1. `OCD_PROJECT_ID`      explicit override, used verbatim.
 *   2. `<state dir>/project-id`  persisted 40-hex id, survives restarts.
 *   3. derive from host + install path (+ random salt), then persist.
 *
 * If the state directory is not writable (read-only container image) the
 * derived value is still a deterministic hash of host + install path, so it
 * stays stable across restarts on that host instead of churning per boot.
 */

import { createHash, randomBytes } from "node:crypto";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { homedir, hostname } from "node:os";
import { join, resolve } from "node:path";

/** Shape upstream accepts and that matches the historical value. */
const PROJECT_ID_SHAPE = /^[0-9a-f]{40}$/;

export type ProjectIdSource = "env" | "state" | "derived";

export interface ProjectId {
  id: string;
  source: ProjectIdSource;
  /** File holding the id when it was read from or written to disk. */
  stateFile: string | null;
}

/** `resolveProjectId` is called per `loadConfig`, which tests do in a loop. */
const cache = new Map<string, ProjectId>();

function sha1(input: string): string {
  return createHash("sha1").update(input).digest("hex");
}

/** State directory for derived identity. `OCD_STATE_DIR` wins over XDG. */
export function projectIdStateDir(env: Record<string, string | undefined> = process.env): string {
  const explicit = env.OCD_STATE_DIR?.trim();
  if (explicit) return resolve(explicit);
  const xdg = env.XDG_STATE_HOME?.trim();
  if (xdg) return join(resolve(xdg), "oc-direct");
  const home = env.HOME?.trim() || homedir();
  return join(home, ".local", "state", "oc-direct");
}

function readId(file: string): string | null {
  try {
    const value = readFileSync(file, "utf8").trim();
    return PROJECT_ID_SHAPE.test(value) ? value : null;
  } catch {
    return null;
  }
}

function persist(file: string, id: string): boolean {
  try {
    mkdirSync(resolve(file, ".."), { recursive: true, mode: 0o700 });
    writeFileSync(file, `${id}\n`, { mode: 0o600 });
    return true;
  } catch {
    return false;
  }
}

export function resolveProjectId(
  env: Record<string, string | undefined> = process.env,
  installDir: string = resolve(import.meta.dir, ".."),
): ProjectId {
  const override = env.OCD_PROJECT_ID?.trim();
  if (override) return { id: override, source: "env", stateFile: null };

  const file = join(projectIdStateDir(env), "project-id");
  const cached = cache.get(file);
  if (cached) return cached;

  const persisted = readId(file);
  if (persisted) {
    const result: ProjectId = { id: persisted, source: "state", stateFile: file };
    cache.set(file, result);
    return result;
  }

  // Fresh install: mint an id, then try to keep it for next boot.
  const minted = sha1(`${hostname()}:${installDir}:${randomBytes(16).toString("hex")}`);
  const result: ProjectId = persist(file, minted)
    ? { id: minted, source: "derived", stateFile: file }
    : // Read-only filesystem: fall back to a value that is stable per host+path.
      { id: sha1(`${hostname()}:${installDir}`), source: "derived", stateFile: null };
  cache.set(file, result);
  return result;
}
