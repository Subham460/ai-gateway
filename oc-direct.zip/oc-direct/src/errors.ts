export type ErrorType =
  | "invalid_request_error"
  | "authentication_error"
  | "rate_limit_error"
  | "timeout_error"
  | "upstream_error"
  | "server_error"
  | "not_found_error";

export class ApiError extends Error {
  readonly status: number;
  readonly type: ErrorType;
  readonly code: string | null;
  readonly param: string | null;
  readonly retryAfterMs: number | null;

  constructor(
    status: number,
    message: string,
    type: ErrorType,
    options: { code?: string | null; param?: string | null; retryAfterMs?: number | null } = {},
  ) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.type = type;
    this.code = options.code ?? null;
    this.param = options.param ?? null;
    this.retryAfterMs = options.retryAfterMs ?? null;
  }

  toOpenAI(): { error: { message: string; type: ErrorType; param: string | null; code: string | null } } {
    return {
      error: {
        message: this.message,
        type: this.type,
        param: this.param,
        code: this.code,
      },
    };
  }
}

export class BadRequestError extends ApiError {
  constructor(message: string, param: string | null = null) {
    super(400, message, "invalid_request_error", { param, code: "invalid_request" });
    this.name = "BadRequestError";
  }
}

export class AuthError extends ApiError {
  constructor(message = "invalid API key") {
    super(401, message, "authentication_error", { code: "invalid_api_key" });
    this.name = "AuthError";
  }
}

export class NotFoundError extends ApiError {
  constructor(message: string) {
    super(404, message, "not_found_error", { code: "not_found" });
    this.name = "NotFoundError";
  }
}

export class RateLimitError extends ApiError {
  constructor(message: string, retryAfterMs: number | null = null) {
    super(429, message, "rate_limit_error", { code: "rate_limit_exceeded", retryAfterMs });
    this.name = "RateLimitError";
  }
}

export class UpstreamHttpError extends ApiError {
  readonly upstreamStatus: number;

  constructor(status: number, message: string, retryAfterMs: number | null = null) {
    const mapped = status === 429 ? 429 : status >= 500 ? 502 : 502;
    super(mapped, message, status === 429 ? "rate_limit_error" : "upstream_error", {
      code: status === 429 ? "free_usage_limit" : "upstream_status",
      retryAfterMs,
    });
    this.name = "UpstreamHttpError";
    this.upstreamStatus = status;
  }
}

export class UpstreamTimeoutError extends ApiError {
  constructor(message = "upstream request timed out") {
    super(504, message, "timeout_error", { code: "timeout" });
    this.name = "UpstreamTimeoutError";
  }
}

export class UpstreamNetworkError extends ApiError {
  constructor(message: string) {
    super(502, message, "upstream_error", { code: "upstream_unreachable" });
    this.name = "UpstreamNetworkError";
  }
}

export class ServiceUnavailableError extends ApiError {
  constructor(message: string, retryAfterMs: number | null = null) {
    super(503, message, "server_error", { code: "service_unavailable", retryAfterMs });
    this.name = "ServiceUnavailableError";
  }
}
