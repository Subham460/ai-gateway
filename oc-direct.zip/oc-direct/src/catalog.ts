/**
 * Static catalog of the free chat models exposed by the OpenCode provider.
 *
 * Kept local on purpose: the gateway must answer `/v1/models` even when the
 * upstream catalog is unreachable, and model limits feed request clamping.
 * Override with `OCD_ALLOW_ANY_MODEL=1` to pass arbitrary provider/model ids.
 */

export interface ModelInfo {
  id: string;
  /** Provider id used by OpenCode. All catalog entries are `opencode`. */
  providerID: string;
  name: string;
  contextWindow: number;
  maxOutputTokens: number;
  /** Unix seconds, for the OpenAI `created` field. */
  released: number;
}

export const FREE_MODELS: readonly ModelInfo[] = [
  {
    id: "deepseek-v4.1-flash-free",
    providerID: "opencode",
    name: "DeepSeek V4.1 Flash Free",
    contextWindow: 200_000,
    maxOutputTokens: 32_000,
    released: 1_792_195_200,
  },
  {
    id: "flint-40b-free",
    providerID: "opencode",
    name: "Flint 40B Free",
    contextWindow: 128_000,
    maxOutputTokens: 16_384,
    released: 1_792_195_200,
  },
  {
    id: "glm-5.3-flash-free",
    providerID: "opencode",
    name: "GLM-5.3-Flash Free",
    contextWindow: 200_000,
    maxOutputTokens: 32_000,
    released: 1_787_702_400,
  },
  {
    id: "big-pickle",
    providerID: "opencode",
    name: "Big Pickle",
    contextWindow: 128_000,
    maxOutputTokens: 16_384,
    released: 1_760_659_200,
  },
  {
    id: "iceman-free",
    providerID: "opencode",
    name: "Iceman Free",
    contextWindow: 128_000,
    maxOutputTokens: 16_384,
    released: 1_793_923_200,
  },
  {
    id: "inkling-2-small-free",
    providerID: "opencode",
    name: "Inkling 2 Small Free",
    contextWindow: 128_000,
    maxOutputTokens: 16_384,
    released: 0,
  },
  {
    id: "longcat-2.5-free",
    providerID: "opencode",
    name: "LongCat 2.5 Free",
    contextWindow: 128_000,
    maxOutputTokens: 16_384,
    released: 0,
  },
  {
    id: "mimo-v2.6-flash-free",
    providerID: "opencode",
    name: "MiMo V2.6 Flash Free",
    contextWindow: 128_000,
    maxOutputTokens: 16_384,
    released: 0,
  },
  {
    id: "minimax-m3.1-flash-free",
    providerID: "opencode",
    name: "MiniMax M3.1 Flash Free",
    contextWindow: 128_000,
    maxOutputTokens: 16_384,
    released: 0,
  },
  {
    id: "nemotron-3.5-lightning-free",
    providerID: "opencode",
    name: "Nemotron 3.5 Lightning Free",
    contextWindow: 128_000,
    maxOutputTokens: 16_384,
    released: 0,
  },
  {
    id: "nemotron-3.5-super-vl-free",
    providerID: "opencode",
    name: "Nemotron 3.5 Super VL Free",
    contextWindow: 128_000,
    maxOutputTokens: 16_384,
    released: 0,
  },
  {
    id: "beam-free",
    providerID: "opencode",
    name: "Beam Free",
    contextWindow: 128_000,
    maxOutputTokens: 16_384,
    released: 0,
  },
];

const BY_ID = new Map(FREE_MODELS.map((m) => [m.id, m]));

/** Resolves `model`, `opencode/model`, or `provider/model` to catalog metadata. */
export function resolveModel(requested: string, allowAny: boolean): ModelInfo | undefined {
  const raw = requested.trim();
  if (!raw) return undefined;
  const slash = raw.indexOf("/");
  const providerID = slash > 0 ? raw.slice(0, slash) : "opencode";
  const id = slash > 0 ? raw.slice(slash + 1) : raw;

  const known = BY_ID.get(id);
  if (known && (slash <= 0 || providerID === known.providerID)) return known;

  if (allowAny) {
    return {
      id,
      providerID,
      name: raw,
      contextWindow: 128_000,
      maxOutputTokens: 32_000,
      released: 0,
    };
  }
  return undefined;
}
