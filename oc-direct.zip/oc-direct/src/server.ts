/**
 * HTTP surface: an OpenAI-compatible API in front of the OpenCode free-tier
 * inference gateway.
 *
 * The service is deliberately stateless: each request mints a fresh session id,
 * assembles the attested payload, and streams the result through. Client-facing
 * concerns (auth, quotas, admission control, backpressure, error mapping,
 * metrics) live here; wire-protocol concerns live in `upstream.ts`.
 */

import { FREE_MODELS, resolveModel } from "./catalog.ts";
import { loadConfig, type ApiKey, type Config } from "./config.ts";
import {
  ApiError,
  AuthError,
  BadRequestError,
  NotFoundError,
  RateLimitError,
  ServiceUnavailableError,
} from "./errors.ts";
import { createLogger, type Logger } from "./logger.ts";
import { Metrics } from "./metrics.ts";
import { SSE_DONE, chunkPayload, completionPayload, newCompletionId, sseFrame, usageChunk } from "./openai.ts";
import { buildUpstreamBody } from "./prompt.ts";
import { QueueTimeoutError, Semaphore, TokenBucket } from "./ratelimit.ts";
import type { ChatRequest, Usage } from "./types.ts";
import { UpstreamClient, type CompleteResult } from "./upstream.ts";

const JSON_HEADERS = { "content-type": "application/json; charset=utf-8" };
const SSE_HEADERS = {
  "content-type": "text/event-stream; charset=utf-8",
  "cache-control": "no-cache, no-transform",
  connection: "keep-alive",
  "x-accel-buffering": "no",
};

interface KeyedBucket {
  id: string;
  bucket: TokenBucket;
}

export interface App {
  fetch(request: Request): Promise<Response>;
  config: Config;
  metrics: Metrics;
  upstream: UpstreamClient;
  inFlight: number;
}

async function digest(value: string): Promise<Uint8Array> {
  return new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)));
}

function constantTimeEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i]! ^ b[i]!;
  return diff === 0;
}

function json(body: unknown, status = 200, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), { status, headers: { ...JSON_HEADERS, ...headers } });
}

function errorResponse(error: ApiError, requestId: string): Response {
  const headers: Record<string, string> = { ...JSON_HEADERS, "x-request-id": requestId };
  if (error.retryAfterMs !== null) headers["retry-after"] = String(Math.max(1, Math.ceil(error.retryAfterMs / 1000)));
  return new Response(JSON.stringify(error.toOpenAI()), { status: error.status, headers });
}

function asApiError(error: unknown): ApiError {
  if (error instanceof ApiError) return error;
  const message = error instanceof Error ? error.message : String(error);
  return new ApiError(500, message || "internal error", "server_error", { code: "internal_error" });
}

export function createApp(config: Config, logger?: Logger): App {
  const log = logger ?? createLogger(config.logLevel, { service: "oc-direct" });
  const metrics = new Metrics();
  const upstream = new UpstreamClient(config, metrics, log);
  const semaphore = new Semaphore(config.maxConcurrency);
  const globalBucket = new TokenBucket(config.rateLimitRpm * 4);

  metrics.set("ocd_inflight_requests", 0);
  metrics.set("ocd_queued_requests", 0);

  metrics.describe("ocd_http_requests_total", "HTTP requests by route and status");
  metrics.describe("ocd_http_duration_ms", "HTTP request duration in milliseconds");
  metrics.describe("ocd_inflight_requests", "Requests currently being served");
  metrics.describe("ocd_queued_requests", "Requests waiting for a concurrency slot");
  metrics.describe("ocd_tokens_total", "Upstream tokens billed to the free tier");
  metrics.describe("ocd_reasoning_tokens_total", "Hidden reasoning tokens included in completion_tokens");
  metrics.describe("ocd_sessions_total", "Session identifiers minted");

  let keyHashes: Array<{ id: string; hash: Uint8Array }> = [];
  let buckets: KeyedBucket[] = [];

  const keysReady = (async () => {
    keyHashes = await Promise.all(
      config.apiKeys.map(async (key: ApiKey) => ({ id: key.id, hash: await digest(key.secret) })),
    );
    buckets = keyHashes.map(({ id }) => ({ id, bucket: new TokenBucket(config.rateLimitRpm) }));
  })();

  let inFlight = 0;

  const authenticate = async (request: Request): Promise<string> => {
    if (config.allowAnonymous) return "anonymous";
    await keysReady;
    const header = request.headers.get("authorization");
    const alternate = request.headers.get("x-api-key");
    let presented: string | null = null;
    if (header && /^bearer\s+/i.test(header)) presented = header.replace(/^bearer\s+/i, "").trim();
    else if (alternate) presented = alternate.trim();
    else if (header) presented = header.trim();
    if (!presented) throw new AuthError("missing bearer token");

    const presentedHash = await digest(presented);
    for (const candidate of keyHashes) {
      if (constantTimeEqual(candidate.hash, presentedHash)) return candidate.id;
    }
    throw new AuthError();
  };

  const admit = (keyId: string): void => {
    const now = Date.now();
    const global = globalBucket.take(1, now);
    if (!global.ok) throw new RateLimitError("gateway rate limit exceeded", global.retryAfterMs);
    const entry = buckets.find((b) => b.id === keyId);
    if (entry) {
      const local = entry.bucket.take(1, now);
      if (!local.ok) throw new RateLimitError("API key rate limit exceeded", local.retryAfterMs);
    }
  };

  const readJsonBody = async (request: Request): Promise<unknown> => {
    const length = Number(request.headers.get("content-length") ?? "0");
    if (Number.isFinite(length) && length > config.maxBodyBytes) {
      throw new ApiError(413, "request body too large", "invalid_request_error", { code: "payload_too_large" });
    }
    const text = await request.text();
    if (text.length > config.maxBodyBytes) {
      throw new ApiError(413, "request body too large", "invalid_request_error", { code: "payload_too_large" });
    }
    if (!text.trim()) throw new BadRequestError("request body is empty");
    try {
      return JSON.parse(text);
    } catch (error) {
      throw new BadRequestError(`invalid JSON: ${(error as Error).message}`);
    }
  };

  const parseChatRequest = (raw: unknown): ChatRequest => {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      throw new BadRequestError("request body must be a JSON object");
    }
    const body = raw as ChatRequest;
    if (typeof body.model !== "string" || !body.model.trim()) {
      throw new BadRequestError("`model` is required", "model");
    }
    if (!Array.isArray(body.messages)) {
      throw new BadRequestError("`messages` must be an array", "messages");
    }
    return body;
  };

  const handleModels = (requestId: string): Response =>
    json(
      {
        object: "list",
        data: FREE_MODELS.map((model) => ({
          id: model.id,
          object: "model",
          created: model.released,
          owned_by: model.providerID,
          context_window: model.contextWindow,
          max_output_tokens: model.maxOutputTokens,
        })),
      },
      200,
      { "x-request-id": requestId },
    );

  const handleModel = (id: string, requestId: string): Response => {
    const model = resolveModel(decodeURIComponent(id), config.allowAnyModel);
    if (!model) throw new NotFoundError(`model '${id}' not found`);
    return json(
      {
        id: model.id,
        object: "model",
        created: model.released,
        owned_by: model.providerID,
        context_window: model.contextWindow,
        max_output_tokens: model.maxOutputTokens,
      },
      200,
      { "x-request-id": requestId },
    );
  };

  const recordUsage = (usage: Usage | null): void => {
    if (!usage) return;
    metrics.inc("ocd_tokens_total", { type: "prompt" }, usage.prompt_tokens);
    metrics.inc("ocd_tokens_total", { type: "completion" }, usage.completion_tokens);
    const reasoning = usage.completion_tokens_details?.reasoning_tokens ?? 0;
    if (reasoning > 0) metrics.inc("ocd_reasoning_tokens_total", undefined, reasoning);
  };

  /**
   * Streams an upstream completion to the client as OpenAI chat chunks.
   * Errors that occur before the upstream responds are thrown, so the caller
   * can still produce a proper HTTP status; errors after the response has
   * started are delivered as an SSE error event.
   */
  const streamCompletion = async (
    request: Request,
    body: ChatRequest,
    upstreamBody: string,
    model: string,
    includeUsage: boolean,
    requestId: string,
    release: () => void,
  ): Promise<Response> => {
    const id = newCompletionId();
    const created = Math.floor(Date.now() / 1000);

    let controller: ReadableStreamDefaultController<Uint8Array> | null = null;
    const buffered: Uint8Array[] = [];
    let closed = false;

    const push = (bytes: Uint8Array): void => {
      if (closed) return;
      if (!controller) {
        buffered.push(bytes);
        return;
      }
      try {
        controller.enqueue(bytes);
      } catch {
        closed = true;
      }
    };

    push(sseFrame(chunkPayload(id, created, model, { role: "assistant", content: "" })));

    const emitReasoning = (delta: string): void => {
      if (config.reasoningMode === "drop") return;
      if (config.reasoningMode === "content") {
        push(sseFrame(chunkPayload(id, created, model, { content: delta })));
        return;
      }
      push(sseFrame(chunkPayload(id, created, model, { reasoning_content: delta })));
    };

    let stream: Awaited<ReturnType<UpstreamClient["open"]>>;
    try {
      stream = await upstream.open({
        body: upstreamBody,
        requestId,
        signal: request.signal,
        onContent: (delta) => push(sseFrame(chunkPayload(id, created, model, { content: delta }))),
        onReasoning: emitReasoning,
        onToolCall: (call) => push(sseFrame(chunkPayload(id, created, model, { tool_calls: [call] }))),
      });
    } catch (error) {
      release();
      throw error;
    }

    const started = Date.now();
    let settled = false;

    const finish = (status: string): void => {
      if (settled) return;
      settled = true;
      release();
      metrics.inc("ocd_http_requests_total", { route: "/v1/chat/completions", status });
      metrics.observe("ocd_http_duration_ms", Date.now() - started, { route: "/v1/chat/completions" });
      metrics.set("ocd_inflight_requests", inFlight);
      metrics.set("ocd_queued_requests", semaphore.queued);
    };

    void stream.result
      .then((result: CompleteResult) => {
        push(sseFrame(chunkPayload(id, created, model, {}, result.finishReason)));
        if (includeUsage && result.usage) push(sseFrame(usageChunk(id, created, model, result.usage)));
        push(SSE_DONE);
        closed = true;
        try {
          controller?.close();
        } catch {}
        recordUsage(result.usage);
        log.info("completion complete", {
          requestId,
          model,
          stream: true,
          tokensIn: result.usage?.prompt_tokens ?? null,
          tokensOut: result.usage?.completion_tokens ?? null,
          reasoningTokens: result.usage?.completion_tokens_details?.reasoning_tokens ?? null,
          reasoningChars: result.reasoning.length,
          finish: result.finishReason,
          ms: result.durationMs,
        });
        finish("200");
      })
      .catch((error: unknown) => {
        const apiError = asApiError(error);
        log.warn("stream failed after headers", { requestId, error: apiError.message });
        push(sseFrame({ error: apiError.toOpenAI().error }));
        push(SSE_DONE);
        closed = true;
        try {
          controller?.close();
        } catch {}
        finish(String(apiError.status));
      });

    const readable = new ReadableStream<Uint8Array>({
      start(ctrl) {
        controller = ctrl;
        for (const bytes of buffered.splice(0)) {
          try {
            ctrl.enqueue(bytes);
          } catch {
            closed = true;
          }
        }
      },
      cancel() {
        closed = true;
        stream.abort();
        finish("499");
      },
    });

    return new Response(readable, {
      status: 200,
      headers: { ...SSE_HEADERS, "x-request-id": requestId, "x-ocd-model": model },
    });
  };

  const handleChat = async (request: Request, keyId: string, requestId: string): Promise<Response> => {
    const raw = await readJsonBody(request);
    const body = parseChatRequest(raw);

    const model = resolveModel(body.model, config.allowAnyModel);
    if (!model) throw new NotFoundError(`model '${body.model}' not found`);

    const built = buildUpstreamBody(body, model, {
      toolsMode: config.toolsMode,
      toolChoice: config.toolChoice,
      chatGuard: config.chatGuard,
      defaultMaxTokens: config.defaultMaxTokens,
      reasoningHeadroomTokens: config.reasoningHeadroomTokens,
    });

    let release: () => void;
    try {
      release = await semaphore.acquire(config.queueTimeoutMs);
    } catch (error) {
      if (error instanceof QueueTimeoutError) {
        throw new ServiceUnavailableError("gateway is at capacity", 1000);
      }
      throw error;
    }

    inFlight += 1;
    metrics.set("ocd_inflight_requests", inFlight);
    metrics.set("ocd_queued_requests", semaphore.queued);

    let released = false;
    const releaseOnce = (): void => {
      if (released) return;
      released = true;
      inFlight = Math.max(0, inFlight - 1);
      metrics.set("ocd_inflight_requests", inFlight);
      metrics.set("ocd_queued_requests", semaphore.queued);
      release();
    };

    log.debug("completion start", {
      requestId,
      key: keyId,
      model: model.id,
      stream: body.stream === true,
      promptChars: built.promptChars,
      maxTokens: built.maxTokens,
    });

    if (body.stream === true) {
      return streamCompletion(
        request,
        body,
        built.body,
        model.id,
        body.stream_options?.include_usage === true,
        requestId,
        releaseOnce,
      );
    }

    const started = Date.now();
    try {
      const result = await upstream.complete({ body: built.body, requestId, signal: request.signal });
      recordUsage(result.usage);
      log.info("completion complete", {
        requestId,
        model: model.id,
        stream: false,
        tokensIn: result.usage?.prompt_tokens ?? null,
        tokensOut: result.usage?.completion_tokens ?? null,
        reasoningTokens: result.usage?.completion_tokens_details?.reasoning_tokens ?? null,
        reasoningChars: result.reasoning.length,
        finish: result.finishReason,
        ms: result.durationMs,
      });
      metrics.inc("ocd_http_requests_total", { route: "/v1/chat/completions", status: "200" });
      metrics.observe("ocd_http_duration_ms", Date.now() - started, { route: "/v1/chat/completions" });
      const visible = config.reasoningMode === "content" ? result.reasoning + result.text : result.text;
      const thought = config.reasoningMode === "separate" ? result.reasoning : "";
      return json(
        completionPayload(newCompletionId(), Math.floor(Date.now() / 1000), model.id, {
          ...result,
          text: visible,
          reasoning: thought,
        }),
        200,
        { "x-request-id": requestId, "x-ocd-model": model.id },
      );
    } finally {
      releaseOnce();
    }
  };

  const fetchHandler = async (request: Request): Promise<Response> => {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";
    const requestId = crypto.randomUUID();
    const started = Date.now();

    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: {
          "access-control-allow-origin": request.headers.get("origin") ?? "*",
          "access-control-allow-methods": "GET, POST, OPTIONS",
          "access-control-allow-headers": "authorization, content-type, x-api-key",
          "access-control-max-age": "86400",
        },
      });
    }

    try {
      if (path === "/healthz") {
        metrics.inc("ocd_http_requests_total", { route: "/healthz", status: "200" });
        return json({ status: "ok", uptime: process.uptime(), version: VERSION }, 200, { "x-request-id": requestId });
      }

      if (path === "/readyz") {
        const ready = upstream.available();
        metrics.inc("ocd_http_requests_total", { route: "/readyz", status: ready ? "200" : "503" });
        return json(
          {
            status: ready ? "ready" : "degraded",
            circuit: upstream.circuitState,
            keys: config.allowAnonymous ? "anonymous" : config.apiKeys.length,
            concurrency: { inFlight, queued: semaphore.queued, max: config.maxConcurrency },
            version: VERSION,
          },
          ready ? 200 : 503,
          { "x-request-id": requestId },
        );
      }

      if (path === "/metrics" && request.method === "GET") {
        if (!config.metricsPublic) await authenticate(request);
        metrics.inc("ocd_http_requests_total", { route: "/metrics", status: "200" });
        return new Response(metrics.render(), {
          status: 200,
          headers: { "content-type": "text/plain; version=0.0.4; charset=utf-8", "x-request-id": requestId },
        });
      }

      if (path === "/v1/models" && request.method === "GET") {
        await authenticate(request);
        metrics.inc("ocd_http_requests_total", { route: "/v1/models", status: "200" });
        return handleModels(requestId);
      }

      if (path.startsWith("/v1/models/") && request.method === "GET") {
        await authenticate(request);
        const response = handleModel(path.slice("/v1/models/".length), requestId);
        metrics.inc("ocd_http_requests_total", { route: "/v1/models/:id", status: "200" });
        return response;
      }

      if (path === "/v1/chat/completions") {
        if (request.method !== "POST") {
          throw new ApiError(405, "method not allowed", "invalid_request_error", { code: "method_not_allowed" });
        }
        const keyId = await authenticate(request);
        admit(keyId);
        return await handleChat(request, keyId, requestId);
      }

      throw new NotFoundError(`no route for ${request.method} ${path}`);
    } catch (error) {
      const apiError = asApiError(error);
      const level = apiError.status >= 500 ? "error" : "warn";
      log[level]("request failed", {
        requestId,
        method: request.method,
        path,
        status: apiError.status,
        error: apiError.message,
        ms: Date.now() - started,
      });
      metrics.inc("ocd_http_requests_total", {
        route: path.startsWith("/v1/models/") ? "/v1/models/:id" : path,
        status: String(apiError.status),
      });
      metrics.observe("ocd_http_duration_ms", Date.now() - started, { route: path });
      return errorResponse(apiError, requestId);
    }
  };

  return {
    fetch: fetchHandler,
    config,
    metrics,
    upstream,
    get inFlight() {
      return inFlight;
    },
  };
}

export const VERSION = "1.0.0";

export interface RunningServer {
  url: string;
  port: number;
  app: App;
  stop(): Promise<void>;
}

export function startServer(config: Config = loadConfig(), logger?: Logger): RunningServer {
  const log = logger ?? createLogger(config.logLevel, { service: "oc-direct" });
  const app = createApp(config, log);

  const server = Bun.serve({
    hostname: config.host,
    port: config.port,
    idleTimeout: 255,
    maxRequestBodySize: config.maxBodyBytes + 4096,
    fetch: app.fetch,
    error(error) {
      log.error("unhandled server error", { error: error.message });
      return json({ error: { message: "internal error", type: "server_error", param: null, code: "internal_error" } }, 500);
    },
  });

  const port = server.port ?? config.port;
  const url = `http://${config.host === "0.0.0.0" || config.host === "::" ? "127.0.0.1" : config.host}:${port}`;
  log.info("listening", {
    url,
    port,
    models: FREE_MODELS.map((m) => m.id).join(","),
    toolsMode: config.toolsMode,
    maxConcurrency: config.maxConcurrency,
    projectId: config.projectId,
    projectIdSource: config.projectIdSource,
  });

  let stopping = false;
  const stop = async (): Promise<void> => {
    if (stopping) return;
    stopping = true;
    log.info("draining", { inFlight: app.inFlight });
    await server.stop();
    const deadline = Date.now() + 30_000;
    while (app.inFlight > 0 && Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
    if (app.inFlight > 0) log.warn("drain deadline exceeded", { inFlight: app.inFlight });
    else log.info("drained");
  };

  return { url, port, app, stop };
}

if (import.meta.main) {
  const config = loadConfig();
  const logger = createLogger(config.logLevel, { service: "oc-direct" });
  const running = startServer(config, logger);

  let shuttingDown = false;
  const shutdown = (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    logger.info("signal received", { signal });
    void running.stop().then(() => process.exit(0));
    setTimeout(() => process.exit(1), 35_000).unref?.();
  };
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}
