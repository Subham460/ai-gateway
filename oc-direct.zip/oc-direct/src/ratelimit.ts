/** Token-bucket rate limiting and a bounded-concurrency semaphore. */

export class TokenBucket {
  private tokens: number;
  private last: number;
  private readonly capacity: number;
  private readonly refillPerMs: number;

  constructor(perMinute: number, burst?: number, now: number = Date.now()) {
    this.capacity = Math.max(1, burst ?? Math.max(1, Math.ceil(perMinute / 6)));
    this.tokens = this.capacity;
    this.refillPerMs = perMinute / 60_000;
    this.last = now;
  }

  take(count = 1, now: number = Date.now()): { ok: boolean; retryAfterMs: number } {
    const elapsed = Math.max(0, now - this.last);
    this.tokens = Math.min(this.capacity, this.tokens + elapsed * this.refillPerMs);
    this.last = now;
    if (this.tokens >= count) {
      this.tokens -= count;
      return { ok: true, retryAfterMs: 0 };
    }
    const missing = count - this.tokens;
    const retryAfterMs = this.refillPerMs > 0 ? Math.ceil(missing / this.refillPerMs) : 60_000;
    return { ok: false, retryAfterMs };
  }
}

export class QueueTimeoutError extends Error {
  constructor() {
    super("server is at capacity");
    this.name = "QueueTimeoutError";
  }
}

export class Semaphore {
  private available: number;
  private waiters: Array<{ resolve: (release: () => void) => void; reject: (err: Error) => void; timer: ReturnType<typeof setTimeout> }> = [];

  constructor(private readonly max: number) {
    this.available = max;
  }

  get inFlight(): number {
    return this.max - this.available;
  }

  get queued(): number {
    return this.waiters.length;
  }

  async acquire(timeoutMs: number): Promise<() => void> {
    const makeRelease = () => {
      let released = false;
      return () => {
        if (released) return;
        released = true;
        this.release();
      };
    };

    if (this.available > 0) {
      this.available -= 1;
      return makeRelease();
    }

    return new Promise<() => void>((resolve, reject) => {
      const timer = setTimeout(() => {
        const idx = this.waiters.findIndex((w) => w.timer === timer);
        if (idx >= 0) this.waiters.splice(idx, 1);
        reject(new QueueTimeoutError());
      }, timeoutMs);
      this.waiters.push({ resolve: (rel) => resolve(rel), reject, timer });
    });
  }

  private release(): void {
    const next = this.waiters.shift();
    if (next) {
      clearTimeout(next.timer);
      next.resolve(
        (() => {
          let done = false;
          return () => {
            if (done) return;
            done = true;
            this.release();
          };
        })(),
      );
      return;
    }
    this.available = Math.min(this.max, this.available + 1);
  }
}
