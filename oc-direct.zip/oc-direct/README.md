# oc-direct

An OpenAI-compatible HTTP API that speaks the OpenCode free-tier inference protocol **directly** — no `opencode` process, no harness, no wrapper process. One Bun service, one TCP socket, the same wire contract the real CLI uses.

```
OpenAI SDK / curl / any client
        │  POST /v1/chat/completions   (standard OpenAI JSON)
        ▼
   oc-direct  ──── canonical payload, attested session id, Bun TLS ───▶  opencode.ai/inference/openai/v1
```

## Why a gateway and not just a client

The free tier is not a plain OpenAI endpoint. Requests are attested server-side, and a request that looks like curl gets `429 FreeUsageLimitError` — with a retry hint measured in **days**, not seconds. The attestation covers five things simultaneously (verified live; `bun run verify:contract` re-checks all of them):

| Requirement | Observation when violated |
| --- | --- |
| `x-opencode-session` / `-session-id` must be a timestamp-derived `ses_` id | random ids → `429 FreeUsageLimitError` |
| system prompt must be the canonical OpenCode harness prompt (8,605 chars) | one-line prompt → `429` |
| tools must be the canonical set (or the `read` subset) | no tools → `429`; a single `bash` tool → `429` |
| `stream: true` | `stream:false` → `429` |
| Bun's TLS/HTTP client fingerprint + `user-agent`, `x-opencode-client`, `x-opencode-project` | Node 22 with identical headers/body → `429` |

That last row is why this service runs on Bun and uses Bun's native `fetch`: the same bytes from Node fail. Everything the client sends afterwards — history, `max_completion_tokens`, `tool_choice`, caller system text — is accepted; `tool_choice: "none"` keeps the contract while suppressing tool calls, so the API behaves like a normal chat endpoint.

The session id must also be *fresh*: `src/ids.ts` reproduces `Session.ID.create` from the 2.2.7 bundle (6 bytes of `~(Date.now()*4096 + counter)` as 12 hex chars, plus 14 base62 random chars). Ids are minted per request; no state is kept anywhere.

## Do I need OpenCode installed?

**No.** The dependency is on the wire *protocol*, not on the OpenCode binary, its config, or its auth state. This service re-implements the contract itself:

| Thing | Where it comes from |
| --- | --- |
| canonical system prompt | frozen file, `src/assets/system-prompt.txt` |
| tool schemas | frozen files, `src/assets/tool-read.json`, `tools-full.json` |
| session id | generated locally, `src/ids.ts` |
| headers, `Bearer public`, `stream: true` | hard-coded in `src/upstream.ts` |

Runtime requirements are exactly two: **Bun ≥ 1.4** and outbound HTTPS to the provider. No `opencode` process, no `node`, no login, no token, no daemon, no `~/.config/opencode`.

The trade-off is that the contract is *captured*, not negotiated: if the provider changes a requirement, the frozen assets go stale and every request becomes `429`. `bun run verify:contract` exists to name which requirement moved before anything else fails.

## Quick start

```bash
cd oc-direct
bun install                       # two dev dependencies; zero runtime deps

# loopback, no auth (development)
OCD_ALLOW_ANONYMOUS=1 bun run start

# or with keys
OCD_KEYS="$(openssl rand -hex 24):local" bun run start
```

Then use it with any OpenAI client:

```bash
curl -s http://127.0.0.1:8787/v1/chat/completions \
  -H 'content-type: application/json' \
  -d '{"model":"deepseek-v4.1-flash-free","messages":[{"role":"user","content":"hello"}]}'

python3 - <<'PY'
from openai import OpenAI
client = OpenAI(base_url="http://127.0.0.1:8787/v1", api_key="anything")
print(client.chat.completions.create(
    model="glm-5.3-flash-free",
    messages=[{"role": "user", "content": "one sentence about tide pools"}],
).choices[0].message.content)
PY
```

`./run.sh` loads `.env`, defaults to loopback, and execs the server so `SIGTERM` reaches it.

## Verification (run in this workspace, against the live endpoint)

```
$ bun test
 52 pass, 0 fail, 140 expect() calls

$ bun run typecheck
 (clean, strict, noUncheckedIndexedAccess)

$ bun run test:integration
 PASS  health                     version 1.0.0
 PASS  readiness                  concurrency max 16
 PASS  model catalog              12 models
 PASS  model detail               context 200000
 PASS  metrics                    13 series lines
 PASS  non-stream completion      "GATEWAY_OK" · 2050 tokens
 PASS  streaming completion       10 frames · "1, 2, 3" · 2073 tokens
 PASS  multi-turn context         "Ada"
 PASS  caller system instructions "HELLO!"
 PASS  reasoning channel          reasoning 0 chars · answer "391"
 PASS  second model               "GLM_OK"
 PASS  unknown model rejected     404 not_found_error
 summary: 12/12 passed

$ bun run verify:contract
 OK    canonical request                          served    (200)
 OK    system prompt replaced by a one-liner      rejected  (429 FreeUsageLimitError)
 OK    no tools                                   rejected  (429 FreeUsageLimitError)
 OK    only a non-read tool                       rejected  (429 FreeUsageLimitError)
 OK    stream disabled                            rejected  (429 FreeUsageLimitError)
 OK    random session id                          rejected  (429 FreeUsageLimitError)
```

`verify:contract` is the drift alarm: it asserts both the positive path and every known 429 trigger, so a provider change fails loudly instead of silently degrading to empty answers.

### Re-verification, 2026-11-13

Local only, to avoid spending the daily free quota; the two live suites above were not re-run.

```
tsc --noEmit                       clean (strict, noUncheckedIndexedAccess)
bun test                           52 pass, 0 fail, 140 expects, 6 files
boot + /healthz /readyz /v1/models 200, ready/closed/16, 12 models
/v1/models/{id}, unknown id        200, 404
validation                         empty body 400, bad JSON 400, missing model 400, unknown route 404
live chat, read mode               200 "OK" · prompt 2038 (1920 cached) · completion 3
live tool call, full+auto          200 shell call · finish_reason "tool_calls"
live prefix caching, turn 2 of 2   2176 of 2293 prompt tokens cached
```

Run `bun run test:integration` before exposing the service; it is the only check that proves the attestation still passes end to end.

## API surface

| Route | Method | Notes |
| --- | --- | --- |
| `/v1/chat/completions` | POST | streaming and non-streaming, `stream_options.include_usage` honoured |
| `/v1/models` | GET | local catalog of the 12 free models (works offline) |
| `/v1/models/{id}` | GET | context window and output ceiling |
| `/healthz` | GET | liveness, unauthenticated |
| `/readyz` | GET | circuit state, key count, concurrency, unauthenticated |
| `/metrics` | GET | Prometheus text format; auth required unless `OCD_METRICS_PUBLIC=1` |

OpenAI-shaped errors throughout: `400 invalid_request_error`, `401 authentication_error`, `404 not_found_error`, `413 payload_too_large`, `429 rate_limit_error` (with `Retry-After` when upstream supplies one), `502 upstream_error`, `503 service_unavailable`, `504 timeout_error`. Errors raised before the upstream responds carry a real HTTP status; errors raised mid-stream arrive as a final `data: {"error":…}` event before `[DONE]`, because headers are already on the wire.

### Reasoning channel

Hybrid free models emit hidden thinking as `delta.reasoning_content` before the answer, and those tokens are charged against `max_completion_tokens` upstream — which is why a 32-token budget can return an empty string after 32 thinking tokens. Handled explicitly:

- `OCD_REASONING_MODE=separate` (default) — pass thinking through as `reasoning_content` on the delta and on the non-stream `message`; `content` stays clean.
- `OCD_REASONING_MODE=content` — fold thinking ahead of the answer (legacy clients that only read `content`).
- `OCD_REASONING_MODE=drop` — discard it.
- `OCD_REASONING_HEADROOM_TOKENS=N` — add `N` to the upstream budget so reasoning cannot starve a small `max_tokens`. Off by default: OpenAI's own contract counts reasoning inside `max_completion_tokens`, so pass-through is the honest default and this is the opt-in convenience.

### Client compatibility

| Client kind | Works | Notes |
| --- | --- | --- |
| `curl`, OpenAI SDKs (Python/Node), LangChain | yes | plain chat completions |
| Chat UIs that accept a custom base URL | yes | set base URL to `http://host:8787/v1`, any key when anonymous |
| OpenCode / agent harnesses wanting their own tools | **partially** | see below |
| `/v1/embeddings`, `/v1/images`, audio | no | text completions only |

A client's own `tools` array is discarded; the gateway always sends the frozen schema. Tool calls therefore only ever name `read` (default) or the 12 canonical names (`shell`, `write`, `edit`, `glob`, `grep`, `webfetch`, `websearch`, `skill`, `subagent`, `question`, `execute`) — so a custom tool can never be called natively. Two supported patterns:

- **Canonical tools** — `OCD_TOOLS_MODE=full OCD_TOOL_CHOICE=auto`. Native `tool_calls` come back, arguments validated against the captured schema. Verified live: `shell {"command":"ls -la /content"}`, `finish_reason: "tool_calls"`.
- **Custom tools by text protocol** — keep `OCD_TOOL_CHOICE=none`, describe the catalogue in a system message, parse the model's text. The only way to expose tools that are not in the canonical set.

Client system text is appended under `# User Instructions` after the canonical prompt, so it steers but never replaces it. Images become a marker; `temperature`, `top_p`, `stop`, `n` are ignored. History is forwarded verbatim: `role:"tool"` becomes `Tool result (name): …` user text, and an assistant turn carrying `tool_calls` with empty content loses its arguments.

### History and caching

The service is stateless: no session memory, no trimming, no compaction, and no context-window enforcement (`context_window` is advertised in `/v1/models` and never applied). Clients must resend the full conversation and manage their own context.

Provider-side prefix caching does work and is worth designing for — measured on a warm instance, same model, read-tools mode:

| Turn | `prompt_tokens` | `cached_tokens` |
| --- | --- | --- |
| 1 (fresh prefix) | 2,278 | 0 |
| 2 (+2 messages) | 2,293 | 2,176 |

Cache keys are content, not the session id, so minting a new `ses_` per request costs nothing. What *does* invalidate it: changing `OCD_TOOLS_MODE` (full mode measured 5,092 prompt tokens, 0 cached), restarting into different tool settings, or putting volatile text in a system message — it sits after the canonical prompt and before history, so a timestamp there busts the cache every turn. Volatile data belongs in the user message.

## Configuration

Everything is environment-driven and validated at boot; a bad value fails fast with the offending variable named. Full reference in `.env.example`.

| Variable | Default | Purpose |
| --- | --- | --- |
| `OCD_KEYS` | *(empty)* | `secret:label,...`; ≥8 chars each, hashed in memory, compared in constant time |
| `OCD_ALLOW_ANONYMOUS` | `0` | accept unauthenticated requests — loopback development only |
| `OCD_HOST` / `OCD_PORT` | `127.0.0.1` / `8787` | listen address |
| `OCD_RATE_LIMIT_RPM` | `120` | per-key token bucket, plus a 4× global bucket |
| `OCD_MAX_CONCURRENCY` | `16` | in-flight completions before queuing |
| `OCD_QUEUE_TIMEOUT_MS` | `30000` | how long a request waits for a slot before `503` |
| `OCD_UPSTREAM_TIMEOUT_MS` | `300000` | whole-request ceiling |
| `OCD_UPSTREAM_IDLE_TIMEOUT_MS` | `120000` | per-chunk stall ceiling (separate from total) |
| `OCD_RETRY_MAX` | `2` | retries for `408/5xx`/network only; never for `429` |
| `OCD_CIRCUIT_THRESHOLD` / `_COOLDOWN_MS` | `6` / `30000` | breaker trips on consecutive hard failures |
| `OCD_TOOLS_MODE` | `read` | `read` (smallest attested set) or `full` |
| `OCD_TOOL_CHOICE` | `none` | `none` suppresses tool calls, `auto` allows them |
| `OCD_CHAT_GUARD` | `1` | with tools suppressed, forbid the model from emitting tool-call markup as text |
| `OCD_DEFAULT_MAX_TOKENS` | `32000` | budget when the client omits `max_tokens` |
| `OCD_REASONING_MODE` | `separate` | see above |
| `OCD_REASONING_HEADROOM_TOKENS` | `0` | see above |
| `OCD_MAX_BODY_BYTES` | `1048576` | rejects oversized bodies before parsing |
| `OCD_LOG_LEVEL` / `OCD_LOG_PROMPTS` | `info` / `false` | structured JSON logs; prompt text off by default |
| `OCD_METRICS_PUBLIC` | `false` | expose `/metrics` without a key |
| `OCD_ALLOW_ANY_MODEL` | `false` | pass through arbitrary `provider/model` ids |

## Operations

```bash
bun run loadtest -- --requests 200 --concurrency 16        # latency, throughput, token totals
bun run loadtest -- --stream true --requests 50            # streaming path
```

- **Metrics** — `ocd_http_requests_total{route,status}`, `ocd_http_duration_ms` (histogram), `ocd_inflight_requests`, `ocd_queued_requests`, `ocd_upstream_requests_total{status}`, `ocd_upstream_duration_ms`, `ocd_upstream_retries_total`, `ocd_upstream_circuit_state` (0/1/2), `ocd_tokens_total{type}`, `ocd_reasoning_tokens_total`, `ocd_sessions_total`.
- **Logs** — one JSON object per line with `ts`, `level`, `msg`, `requestId`; every response carries `x-request-id`. Prompt text is only logged when `OCD_LOG_PROMPTS=1`.
- **Graceful shutdown** — `SIGTERM`/`SIGINT` stop accepting, drain in-flight requests for up to 30s, then exit; `SIGKILL` only after that window.
- **Cancellation** — client disconnects abort the upstream request through an `AbortSignal`, so abandoned completions do not keep burning quota.

Deployment artefacts live in `deploy/`:

- `Dockerfile` — `oven/bun:1.4-alpine`, non-root user, healthcheck, no build step.
- `docker-compose.yml` — loopback port binding, read-only rootfs, `cap_drop: ALL`, memory/CPU caps, log rotation.
- `oc-direct.service` — hardened systemd unit (`ProtectSystem=strict`, `RestrictAddressFamilies`, `SystemCallFilter=@system-service`, `MemoryMax`).
- `Caddyfile` — TLS termination with `flush_interval -1` so SSE is never buffered and gzip never touches `text/event-stream`.

`INSTALL.md` is the ten-minute runbook for a normal host; `KAGGLE.md` covers running it in a Kaggle notebook (dataset upload, Bun install, outbound tunnel, session limits); `PRODUCTION.md` documents the full-functionality profile (`.env.full`, canonical tools declared) and how to host it so it is reachable from any client; `CLIENT-TESTING.md` is the layer-by-layer test sheet for a public URL.

## Layout

```
src/server.ts     HTTP surface: routing, auth, quotas, admission, SSE framing, error mapping
src/upstream.ts   wire client: attested headers, session minting, retries, breaker, stream parse
src/prompt.ts     canonical payload assembly (system prompt, tools, history folding, budget)
src/ids.ts        session id generator/decoder
src/openai.ts     OpenAI chunk/completion shapes, including reasoning_content
src/catalog.ts    offline model catalog (12 free models, context + output ceilings)
src/ratelimit.ts  token bucket + bounded semaphore
src/circuit.ts    consecutive-failure circuit breaker
src/metrics.ts    dependency-free Prometheus registry
src/sse.ts        incremental SSE parser (arbitrary chunk boundaries, CRLF, multi-line data)
src/assets/       captured canonical system prompt and tool schemas
scripts/          load generator, contract drift checker
test/             52 unit tests + live integration suite
```

## Security posture

The service holds no user data and writes nothing to disk: requests are stateless, session ids are ephemeral, and the client's conversation is forwarded and dropped. API keys are compared as SHA-256 digests in constant time and never logged. Bind to loopback (the compose file does) and put TLS in front before exposing it; a public listener without `OCD_KEYS` is a public proxy to your quota.

## Known limits

- **Quota is the provider's.** `429` is surfaced faithfully as `rate_limit_error` with upstream's retry hint; the gateway does not try to evade it, and retries never apply to it.
- **Text only.** Image parts are replaced with a marker; audio and embeddings have no upstream equivalent.
- **`temperature`, `top_p`, `stop`, `n` and friends are ignored** — the attested payload accepts them inconsistently, so the gateway does not forward them rather than silently changing results per model.
- **Output ceilings are catalog values**; upstream can still finish early with `finish_reason: "length"` when reasoning consumes the budget.
- **Contract drift is a real failure mode.** The assets are captured from OpenCode 2.2.7; after an upstream change, `verify:contract` reports which requirement moved before anything else does.
