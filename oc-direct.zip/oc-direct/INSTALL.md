# Install runbook

Ten minutes, one prerequisite. `oc-direct` needs **Bun ≥ 1.4** and outbound HTTPS — no Node, no OpenCode, no login.

## 1. Unpack

```bash
unzip oc-direct.zip -d oc-direct && cd oc-direct
```

The archive has no runtime dependencies. If `node_modules/` is absent, step 3 fetches the two dev-only packages (`typescript`, `@types/bun`); the service itself runs without them.

## 2. Install Bun

```bash
curl -fsSL https://bun.sh/install | bash      # → ~/.bun/bin/bun
exec $SHELL -l                                 # pick up PATH
bun --version                                  # expect 1.4.x or newer
```

Alternatives: `npm i -g bun`, `brew install oven-sh/bun/bun`, or `docker run --rm oven/bun:1.4-alpine bun --version`.
Windows: use WSL2 or the Dockerfile in `deploy/`; Bun does not run natively on Windows.

## 3. Install dev dependencies

```bash
bun install
```

Offline machine? Skip this. Nothing at runtime imports these; only `bun run typecheck` and the editor need them.

## 4. Configure

```bash
cp .env.example .env
```

Minimum viable `.env`:

```ini
# loopback development — no auth
OCD_ALLOW_ANONYMOUS=1
OCD_HOST=127.0.0.1
OCD_PORT=8787
```

Anything reachable from another machine:

```ini
OCD_KEYS=<openssl rand -hex 24>:laptop
OCD_HOST=0.0.0.0
```

`OCD_KEYS` may hold several `secret:label` pairs, comma separated. Anonymous mode plus a non-loopback bind is an open proxy to your quota — the config validator allows it, but don't.

## 5. Start

```bash
./run.sh
```

Expect a single JSON line: `{"msg":"listening","url":"http://127.0.0.1:8787","models":"deepseek-v4.1-flash-free,..."}`.

## 6. Smoke test (one upstream call, ~2k prompt tokens)

```bash
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8787/healthz   # 200, no upstream

curl -s http://127.0.0.1:8787/v1/chat/completions \
  -H "content-type: application/json" \
  -H "authorization: Bearer $OCD_KEY" \
  -d '{"model":"glm-5.3-flash-free","messages":[{"role":"user","content":"say OK"}],"max_tokens":16}'
```

`{"choices":[{"message":{"content":"OK"}}]}` means the whole chain works. A `429 FreeUsageLimitError` means the captured contract has drifted — go to step 8.

## 7. Confirm before trusting it

```bash
bun test                     # 52 unit tests, no network, no quota
bun run test:integration     # 12 live calls — proves the attestation holds today
```

## 8. If it 429s

```bash
bun run verify:contract      # names which requirement moved, ~6 calls
```

Then re-capture what moved: `src/assets/system-prompt.txt`, `src/assets/tool-*.json`, or the header set in `src/upstream.ts`. Do not retry in a loop — the retry hint is measured in days.

## 9. Expose it (optional)

```bash
# quick and temporary
cloudflared tunnel --url http://127.0.0.1:8787

# or a real host
docker compose -f deploy/docker-compose.yml up -d      # loopback-bound
# then put Caddy in front: deploy/Caddyfile
```

Set `OCD_KEYS` first, keep `OCD_ALLOW_ANONYMOUS=0`, and keep `/metrics` private unless you mean it.

## 10. Point a client at it

```python
from openai import OpenAI
client = OpenAI(base_url="http://127.0.0.1:8787/v1", api_key="<your OCD_KEYS secret>")
```

Works with any OpenAI SDK, chat UI that accepts a custom base URL, or `curl`. Custom tool schemas do not survive — see "Client compatibility" in `README.md` before building an agent loop on top.

## Checklist

- [ ] `bun --version` ≥ 1.4
- [ ] `.env` has keys, or anonymous + loopback only
- [ ] `/healthz` 200
- [ ] one chat call returns text
- [ ] `bun test` 52/52
- [ ] `bun run test:integration` 12/12 (before public exposure)
- [ ] `OCD_KEYS` set and `/metrics` private (if exposed)
