# Full-functionality profile and hosting

What "full functionality" means for this gateway, how to configure it, and where to run it so it is reachable from any client instead of only from a notebook cell.

---

## 1. What full actually covers

The ceiling is set by the upstream contract, not by this code. Anything below the line cannot be added without breaking attestation.

| Capability | Full profile |
| --- | --- |
| `POST /v1/chat/completions`, streaming and non-stream | yes |
| `GET /v1/models`, `GET /v1/models/{id}` | yes, 12 models, works offline |
| Native tool calls, 12 canonical tools | **yes** (`OCD_TOOLS_MODE=full` + `OCD_TOOL_CHOICE=auto`) |
| Custom tool schemas from your client | **no** — upstream attests the tool set; a foreign schema returns `429` |
| Reasoning pass-through (`reasoning_content`) | yes, all three modes |
| Long outputs (32k ceiling per model) | yes |
| Multi-key auth, per-key + global rate limits | yes |
| Prometheus metrics, JSON logs, request ids | yes |
| Retries, circuit breaker, cancellation, graceful shutdown | yes |
| `/v1/embeddings`, `/v1/images`, `/v1/audio`, `/v1/responses` | **no** — no upstream equivalent |
| Image/PDF input | **no** — replaced with `[image omitted…]` |
| `temperature`, `top_p`, `stop`, `n`, `seed` | **no** — not forwarded |
| Server-side conversation memory | **no** — stateless by design; resend history |
| Prompt caching | provider-side prefix cache, automatic |
| Tool history fidelity | `role:"tool"` flattened to user text; assistant `tool_calls` args dropped |

"Use it anywhere" therefore means: any OpenAI-compatible client, anywhere, for chat and canonical-tool work — with the entries marked **no** genuinely absent.

---

## 2. The profile

Copy `.env.full` to `.env` and put a real key in it:

```bash
cp .env.full .env
sed -i "s|^OCD_KEYS=.*|OCD_KEYS=$(openssl rand -hex 24):main|" .env
chmod 600 .env
grep -v '^#' .env | grep .
```

The settings that matter:

| Variable | Full value | Why |
| --- | --- | --- |
| `OCD_KEYS` | `secret:label` | the only thing between the internet and your quota |
| `OCD_HOST` | `0.0.0.0` | container/VM must listen off-loopback |
| `OCD_TOOLS_MODE` | `full` | declares the 12 canonical tools |
| `OCD_TOOL_CHOICE` | `auto` | lets the model actually call them |
| `OCD_CHAT_GUARD` | `1` | safety net: if you flip `tool_choice` back to `none`, the model stops emitting tool markup as text |
| `OCD_REASONING_MODE` | `separate` | keeps `content` clean, exposes thinking separately |
| `OCD_METRICS_PUBLIC` | `false` | `/metrics` stays behind the key |
| `OCD_RATE_LIMIT_RPM` | `120` | per key; global bucket is 4× |

Cost note: `full` mode sends ~5,092 prompt tokens per request instead of ~2,038. On the same provider, the prefix caches after the first call, so steady-state is mostly cache hits — but the first call after every restart pays full price.

---

## 3. Where to run it

| Host | Fits "anywhere"? | Notes |
| --- | --- | --- |
| VPS + Docker Compose + Caddy | **yes** | the intended deployment; `deploy/` is already wired for it |
| Fly.io / Railway / Render / Koyeb | yes | run the Dockerfile, set env vars, expose 8787; SSE needs no special config |
| Home server + Cloudflare Tunnel | yes | keep `OCD_KEYS` on, point the tunnel at `127.0.0.1:8787` |
| Kaggle notebook | **no** | session dies, hostname rotates, no inbound ports — demo only |
| Serverless/edge functions | no | completions outlive the request budget; needs a long-lived process |

---

## 4. VPS, step by step

```bash
# 1. prerequisites on a fresh Debian/Ubuntu box
sudo apt-get update && sudo apt-get install -y docker.io docker-compose-plugin
sudo usermod -aG docker "$USER" && newgrp docker

# 2. get the source (rsync the project dir, or clone your own repo)
rsync -av ./oc-direct/ server:~/oc-direct/
ssh server 'cd ~/oc-direct && ls deploy'

# 3. config
ssh server
cd ~/oc-direct
cp .env.full .env
sed -i "s|^OCD_KEYS=.*|OCD_KEYS=$(openssl rand -hex 24):main|" .env
chmod 600 .env

# 4. run (compose binds the port to loopback on purpose)
docker compose -f deploy/docker-compose.yml up -d --build
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8787/healthz     # 200

# 5. TLS in front
sudo cp deploy/Caddyfile /etc/caddy/Caddyfile      # edit the domain + email first
sudo systemctl restart caddy
curl -s -o /dev/null -w '%{http_code}\n' https://gateway.example.com/healthz   # 200
```

DNS: an `A`/`AAAA` record for `gateway.example.com` pointing at the box, ports 80 and 443 open. Caddy issues and renews the certificate; nothing else needs to know about TLS.

Hardening already in the compose file: read-only root filesystem, `cap_drop: ALL`, `no-new-privileges`, memory/CPU caps, log rotation, loopback-only port publish. Keep it that way — the container holds no data, so it should own nothing.

Systemd alternative (no Docker): `deploy/oc-direct.service`, already hardened; install Bun, copy `deploy/oc-direct.service` to `/etc/systemd/system/`, `systemctl enable --now oc-direct`.

---

## 5. Verify from outside

```bash
export URL='https://gateway.example.com'
export KEY='<the secret in .env>'

curl -s -o /dev/null -w 'health   %{http_code}\n' "$URL/healthz"
curl -s -o /dev/null -w 'no key   %{http_code}\n' "$URL/v1/models"                      # 401
curl -s -o /dev/null -w 'with key %{http_code}\n' -H "authorization: Bearer $KEY" "$URL/v1/models"

# tool path — the thing "full" buys you
curl -s "$URL/v1/chat/completions" -H 'content-type: application/json' \
  -H "authorization: Bearer $KEY" \
  -d '{"model":"glm-5.3-flash-free","messages":[{"role":"user","content":"list files in /tmp with the shell tool"}],"max_tokens":80}' \
  | head -c 400
```

Expect a `tool_calls` block naming `shell`. If you get prose instead, the model chose not to call — retry once with an explicit instruction before assuming a fault.

---

## 6. Point any client at it

| Field | Value |
| --- | --- |
| Base URL | `https://gateway.example.com/v1` |
| API key | `secret` from `OCD_KEYS` |
| Model | any of the 12 ids, e.g. `glm-5.3-flash-free` |

- **SDKs**: `base_url` / `baseURL` — nothing else.
- **Continue**: `provider: openai`, `apiBase: https://…/v1`, `apiKey`, `model`.
- **Cline / Roo / Kilo**: provider *OpenAI Compatible*, base URL, key, model id.
- **Chat UIs** (Cherry Studio, Chatbox, LibreChat, Open WebUI): custom OpenAI provider.
- **Copilot**: no base-URL setting; use VS Code BYOK if your build has it, otherwise a BYOK extension.

Agentic clients get the 12 canonical tools (`shell`, `read`, `write`, `edit`, `glob`, `grep`, `webfetch`, `websearch`, `skill`, `subagent`, `question`, `execute`) with the captured 2.2.7 argument schemas. Names and shapes are frozen — a client expecting different names will receive calls it cannot dispatch.

---

## 7. Operating it

```bash
docker compose -f deploy/docker-compose.yml logs -f --tail=50
curl -s -H "authorization: Bearer $KEY" https://gateway.example.com/metrics | head -40
docker compose -f deploy/docker-compose.yml pull && docker compose -f deploy/docker-compose.yml up -d
```

- **Quota** is the provider's. `429` is relayed with upstream's `Retry-After`; retries never apply to it. If everything 429s, run `bun run verify:contract` — the captured assets may have aged out.
- **Keys**: rotate by editing `OCD_KEYS` and restarting; digests are in memory only.
- **Logs**: one JSON line per request, prompts redacted unless `OCD_LOG_PROMPTS=1`. Never enable that on a shared host.
- **Updating**: replace `src/` and restart. No migrations, no data.
- **Context**: nothing is trimmed for you; a client that resends 150k tokens pays for 150k every turn.

---

## 8. Honest limits

1. Tool set is frozen to the captured 2.2.7 schemas. Custom tools require a text protocol you parse yourself.
2. No embeddings, images, audio, or `/v1/responses`.
3. Sampling parameters are ignored — one less knob, no silent behaviour changes per model.
4. Stateless: no memory, no conversation store, no trimming.
5. Contract drift is a real failure mode; `verify:contract` is the alarm, run it after any upstream change.
6. Quota is shared with everything else on the account — a public endpoint spends it as fast as your visitors can type.

---

## 9. Checklist

- [ ] `.env` from `.env.full`, `OCD_KEYS` set, mode `0600`
- [ ] `OCD_TOOLS_MODE=full`, `OCD_TOOL_CHOICE=auto`
- [ ] container listening, `/healthz` 200 on the host
- [ ] TLS terminates at Caddy, HSTS present
- [ ] `/v1/models` 401 without key, 200 with
- [ ] one chat call and one tool call succeed from outside
- [ ] `/metrics` still returns 401 without the key
- [ ] `bun test` 55/55 and `verify:contract` clean after any update
