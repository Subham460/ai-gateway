# Testing a public oc-direct URL with real clients

You have a running gateway behind a Cloudflare quick tunnel:

```
https://<random-name>.trycloudflare.com     ← Cloudflare Quick Tunnel (cloudflared)
        └─► http://127.0.0.1:8787            ← oc-direct inside the Kaggle notebook
```

Test in layers, in this order. Each step isolates one thing, so a failure tells you exactly which layer is broken: tunnel, auth, upstream contract, or client configuration. Steps 1–2 cost no quota except the two chat calls marked 💰.

---

## 0. Collect the two values you need

```python
import os
print(open("/tmp/ocd-key").read().strip())        # API key
print(open("/tmp/tunnel.log").read()[-800:])      # URL, if you lost it
```

```bash
export URL='https://<random-name>.trycloudflare.com'   # no trailing slash
export KEY='<the key printed above>'
```

Rules that trip people up:

- The base URL for a client is `$URL/v1` — **with** `/v1`. In `curl` you write the full path.
- The key is the part *before* the colon in `.env` (`OCD_KEYS=secret:label`). Never send `secret:label`.
- Quick tunnels mint a **new hostname on every restart**. If the notebook restarted, everything below uses the old, dead URL.

---

## 1. Tunnel + auth, no quota

```bash
curl -s -o /dev/null -w 'healthz   %{http_code}\n' "$URL/healthz"
curl -s -o /dev/null -w 'no key    %{http_code}\n' "$URL/v1/models"
curl -s -o /dev/null -w 'with key  %{http_code}\n' -H "authorization: Bearer $KEY" "$URL/v1/models"
curl -s -H "authorization: Bearer $KEY" "$URL/v1/models" | head -c 240; echo
```

| Result | Meaning |
| --- | --- |
| `healthz 200`, `no key 401`, `with key 200`, model list | tunnel + auth are fine, continue |
| `healthz 000` / connection refused | tunnel dead or session ended |
| `healthz 502` / `1033` from Cloudflare | cloudflared cannot reach `127.0.0.1:8787` — server crashed, check `/tmp/ocd.log` |
| `no key 200` | `OCD_ALLOW_ANONYMOUS=1` is set — anyone with the URL spends your quota. Fix before sharing |
| `with key 401` | wrong secret, or the key belongs to another `.env` (regenerated on restart) |

Confirm the hostname is the live one:

```bash
grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' /tmp/tunnel.log | tail -1
```

---

## 2. Completion paths, one call each 💰💰

Non-stream:

```bash
curl -s "$URL/v1/chat/completions" \
  -H 'content-type: application/json' \
  -H "authorization: Bearer $KEY" \
  -d '{"model":"glm-5.3-flash-free","messages":[{"role":"user","content":"say OK"}],"max_tokens":16}'
```

Expect `"content":"OK"` and `"usage":{"prompt_tokens":2038,...}`.

Stream (this is where proxies buffer):

```bash
curl -N -s "$URL/v1/chat/completions" \
  -H 'content-type: application/json' \
  -H "authorization: Bearer $KEY" \
  -d '{"model":"glm-5.3-flash-free","messages":[{"role":"user","content":"count to five"}],"stream":true,"max_tokens":64}'
```

Frames should trickle in with visible gaps. If the whole body lands at the end, the proxy or client is buffering: the answer is still correct, the UI just looks frozen. Drop to `stream:false` in that client.

Tool path (optional, proves the canonical tools work through the tunnel):

```bash
curl -s "$URL/v1/chat/completions" \
  -H 'content-type: application/json' \
  -H "authorization: Bearer $KEY" \
  -d '{"model":"glm-5.3-flash-free","messages":[{"role":"user","content":"list files in /tmp using the shell tool"}],"max_tokens":80}'
```

With the server on defaults (`OCD_TOOLS_MODE=read`, `OCD_TOOL_CHOICE=none`) this returns prose — correct behaviour. Tool calls only appear when the server runs with `full` + `auto`.

---

## 3. The three values every client needs

| Field | Value |
| --- | --- |
| Base URL | `https://<random-name>.trycloudflare.com/v1` |
| API key | the secret from `OCD_KEYS` |
| Model | one of the 12 catalog ids: `glm-5.3-flash-free`, `deepseek-v4.1-flash-free`, `minimax-m3.1-flash-free`, … |

Model ids are fixed strings. Clients with a "fetch models" button will usually succeed (`GET /v1/models` is implemented), but type the id manually if the button sits behind an auth step.

---

## 4. Qoder

Settings → model/provider configuration → add an **OpenAI-compatible / custom** provider:

- Base URL: `https://<random>.trycloudflare.com/v1`
- API key: your secret
- Model: type `glm-5.3-flash-free` by hand

Expect limits:

- **Agent mode is the wrong tool here.** Qoder sends its own tool schemas; the gateway replaces them with the captured set. File-editing actions either do nothing or come back as text.
- **Chat/completions only.** No `/v1/responses`, no embeddings, no image input.
- If the current Qoder build has no custom-endpoint field, use a BYOK editor instead (§6). Nothing is required from the gateway side — it is a plain OpenAI endpoint.

Test inside Qoder with a throwaway prompt: "reply with the word OK". If that works, the wiring is right and any weirdness afterwards is the tool/agent layer, not the tunnel.

---

## 5. Copilot

GitHub Copilot is bound to GitHub's backend and has no base-URL setting; you cannot point it at the tunnel. Two honest options:

1. **BYOK in VS Code Copilot Chat**, if your build ships it: model picker → *Manage Models* → *OpenAI Compatible* → paste base URL, key, model id. Menu wording varies by build — read the picker instead of trusting a path in a doc.
2. **Use a BYOK extension and leave Copilot alone**: Continue, Cline, Roo Code, Kilo Code. All take base URL + key + model and are the reliable path on any build.

If the extension offers "agent" or "tool use" toggles, turn them off for this endpoint.

---

## 6. Client snippets

**Continue** (`~/.continue/config.yaml`):

```yaml
models:
  - name: oc-direct
    provider: openai
    model: glm-5.3-flash-free
    apiBase: https://<random>.trycloudflare.com/v1
    apiKey: <secret>
    roles: [chat, edit]
```

**Cline / Roo / Kilo** (GUI): API Provider → *OpenAI Compatible* → Base URL `https://…/v1`, API Key, Model ID `glm-5.3-flash-free`. Disable "Use tools"/agent mode.

**Cherry Studio / Chatbox / LobeChat / Open WebUI / LibreChat**: add provider type *OpenAI*, base URL with `/v1`, key, then add the model id manually.

**Python SDK** (sanity check outside the notebook):

```python
from openai import OpenAI
c = OpenAI(base_url="https://<random>.trycloudflare.com/v1", api_key="<secret>")
print(c.chat.completions.create(
    model="glm-5.3-flash-free",
    messages=[{"role": "user", "content": "say OK"}],
).choices[0].message.content)
```

**Node SDK**:

```js
import OpenAI from "openai";
const c = new OpenAI({ baseURL: "https://<random>.trycloudflare.com/v1", apiKey: "<secret>" });
console.log((await c.chat.completions.create({
  model: "glm-5.3-flash-free",
  messages: [{ role: "user", content: "say OK" }],
})).choices[0].message.content);
```

---

## 7. What looks broken and is by design

| Symptom | Cause |
| --- | --- |
| Agent mode can't apply edits | client tools discarded; only `read` or the 12 canonical tools exist |
| Your system prompt seems ignored | appended as `# User Instructions` after the canonical prompt; it steers, doesn't lead |
| ~2k tokens billed for "hi" | the attested system prompt rides in every request |
| Images / PDFs ignored | text-only; image parts become `[image omitted…]` |
| `temperature`, `top_p`, `stop`, `n` have no effect | deliberately not forwarded |
| Streaming arrives in one burst | proxy buffering; use `stream:false` |
| `finish_reason: "length"` with empty content | hidden reasoning consumed the budget — raise `max_tokens`, or start the server with `OCD_REASONING_HEADROOM_TOKENS=512` |
| Works, then dies after idle | Kaggle ended the session; tunnel and server died with it |
| `429 FreeUsageLimitError` | daily quota or contract drift — run `bun run verify:contract` |
| Model prints `<\|DSML\| invoke …>` or `<function=…>` as text | tools are suppressed but the client's system text advertises them; see §7.1 |

### 7.1 It prints tool-call markup instead of answering

Symptom: the reply contains `<|DSML| calls>`, `<|DSML| invoke name="execute">`, or similar XML-ish blocks. Nothing executes and the client shows raw text.

Cause: your client told the model about tools in its system prompt, while the gateway declared only `read` with `tool_choice: none`. The model emits its training-time tool syntax as ordinary content.

Fix A — let it call tools for real (server side):

```python
import os, subprocess, time
os.chdir("/kaggle/working/oc-direct")
lines = [l for l in open(".env").read().splitlines()
         if not l.startswith(("OCD_TOOLS_MODE", "OCD_TOOL_CHOICE"))]
lines += ["OCD_TOOLS_MODE=full", "OCD_TOOL_CHOICE=auto"]
open(".env", "w").write("\n".join(lines) + "\n")
subprocess.run(["pkill", "-f", "src/server.ts"]); time.sleep(1)
subprocess.Popen(["bash", "./run.sh"], cwd="/kaggle/working/oc-direct",
                 stdout=open("/tmp/ocd.log", "w"), stderr=subprocess.STDOUT, start_new_session=True)
time.sleep(3); print(open("/tmp/ocd.log").readline()[:140])   # expect "toolsMode":"full"
```

Cost: ~5,092 prompt tokens per request instead of ~2,038, cold cache on the first calls.

Fix B — keep chat mode and silence the markup (default since 1.0.1):

`OCD_CHAT_GUARD=1` appends a `# Tool Availability` directive when tools are suppressed, so the model answers in prose instead of inventing calls. Verified against `deepseek-v4.1-flash-free`: the reply came back as "Tool use is disabled for this turn…" with no markup. Turn it off with `OCD_CHAT_GUARD=0` if you want the raw prompt untouched.

What it is **not**: MCP. The gateway has no MCP client and never sees MCP servers; a model that offers to "check MCP" is reciting your client's prompt.

---

## 8. Tunnel-specific failures

| Symptom | Fix |
| --- | --- |
| Chrome shows Cloudflare `1033` | cloudflared up, server down: `pgrep -af "src/server.ts"`, `/tmp/ocd.log` |
| `524` after ~100 s | upstream slower than the edge timeout; lower `max_tokens`, or use streaming |
| URL works on one network, not another | corporate DNS/proxy blocks `trycloudflare.com`; try mobile data |
| URL stops resolving after a while | quick tunnel expired or the notebook restarted; read a fresh URL from `/tmp/tunnel.log` |
| Everything 403 | Cloudflare Access / WAF in front — quick tunnels don't add that; check you didn't gate it |

Restart the pair in the right order:

```python
import subprocess, time
subprocess.run(["pkill", "-f", "src/server.ts"]); subprocess.run(["pkill", "-f", "cloudflared"])
time.sleep(1)
# then re-run the start cell, then the tunnel cell, then re-read the URL
```

---

## 9. Handling the URL like a credential

- The URL alone gets `401`; URL **plus key** spends your quota. Treat the pair as a password.
- Quick tunnels are public DNS names — assume they are discoverable. Never leave `OCD_ALLOW_ANONYMOUS=1` on a tunnelled listener.
- Rotate by regenerating `OCD_KEYS` (cell 4) and restarting; old keys die with the process.
- The key lives in `/tmp/ocd-key` and `.env`. `/tmp` is wiped on kernel restart; `.env` in `/kaggle/working` survives if you *Save Version*.
- Don't paste the key into a notebook cell if the notebook isn't private.

---

## 10. Checklist

- [ ] `healthz` 200 through the public URL
- [ ] `/v1/models` 401 without key, 200 with key
- [ ] non-stream completion returns text
- [ ] stream completion returns frames incrementally
- [ ] model id typed manually matches the catalog (`deepseek-v4.1-flash-free`, …)
- [ ] client uses base URL **with** `/v1`
- [ ] key is the secret only, not `secret:label`
- [ ] agent/tool mode disabled in the client
- [ ] `max_tokens` set low in the client (defaults can be 32k)
- [ ] tunnel URL re-read after any notebook restart

## 11. Test log

| Client | Base URL | Auth | Non-stream | Stream | Notes |
| --- | --- | --- | --- | --- | --- |
| `curl` | | ☐ 200 / ☐ 401 | ☐ | ☐ | |
| Python SDK | | | ☐ | ☐ | |
| Qoder | | | ☐ | ☐ | agent mode off |
| Continue | | | ☐ | ☐ | |
| Cline / Roo | | | ☐ | ☐ | tools off |
| Cherry Studio | | | ☐ | ☐ | |
| Copilot BYOK | | | ☐ | ☐ | if available |
