/**
 * Load generator for the gateway.
 *
 *   bun run scripts/loadtest.ts --requests 200 --concurrency 16 --model deepseek-v4.1-flash-free
 *
 * Measures the gateway's own overhead with keep-alive reuse, reports latency
 * percentiles, status-class distribution, throughput and token totals. Every
 * completion asks for one word, so the free-tier cost stays minimal.
 *
 * Flags:
 *   --url          base url of the gateway        (default http://127.0.0.1:8787)
 *   --key          bearer token                   (default $OCD_LOADTEST_KEY)
 *   --model        model id                       (default deepseek-v4.1-flash-free)
 *   --requests     total completions              (default 100)
 *   --concurrency  parallel workers               (default 8)
 *   --stream       "true" to stream responses     (default false)
 *   --prompt       user prompt                    (default "Reply with one word: ok")
 *   --max-tokens   completion budget              (default 16)
 *   --timeout      per-request timeout in ms      (default 120000)
 */

const args = new Map<string, string>();
for (let i = 2; i < process.argv.length; i++) {
  const arg = process.argv[i]!;
  if (!arg.startsWith("--")) continue;
  const [name, inline] = arg.slice(2).split("=", 2);
  const flag = name!;
  const value = inline ?? process.argv[++i] ?? "true";
  args.set(flag, value);
}

const url = (args.get("url") ?? process.env.OCD_LOADTEST_URL ?? "http://127.0.0.1:8787").replace(/\/+$/, "");
const key = args.get("key") ?? process.env.OCD_LOADTEST_KEY ?? "";
const model = args.get("model") ?? "deepseek-v4.1-flash-free";
const total = Number(args.get("requests") ?? 100);
const concurrency = Math.max(1, Number(args.get("concurrency") ?? 8));
const stream = (args.get("stream") ?? "false") === "true";
const prompt = args.get("prompt") ?? "Reply with one word: ok";
const maxTokens = Number(args.get("max-tokens") ?? 16);
const timeoutMs = Number(args.get("timeout") ?? 120_000);

if (!Number.isFinite(total) || total < 1) throw new Error("--requests must be a positive integer");

interface Sample {
  ms: number;
  status: number;
  tokens: number;
}

const samples: Sample[] = [];
const statuses = new Map<number, number>();
let sent = 0;
let failed = 0;
let tokens = 0;

function percentile(sorted: number[], p: number): number {
  if (sorted.length === 0) return 0;
  const index = Math.min(sorted.length - 1, Math.floor((p / 100) * sorted.length));
  return sorted[index]!;
}

async function one(): Promise<void> {
  const started = performance.now();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let status = 0;
  let used = 0;
  try {
    const response = await fetch(`${url}/v1/chat/completions`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        ...(key ? { authorization: `Bearer ${key}` } : {}),
      },
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: prompt }],
        max_completion_tokens: maxTokens,
        ...(stream ? { stream: true, stream_options: { include_usage: true } } : {}),
      }),
      signal: controller.signal,
    });
    status = response.status;
    const body = await response.text();
    if (stream) {
      for (const line of body.split("\n")) {
        if (!line.startsWith("data: ") || line === "data: [DONE]") continue;
        try {
          const chunk = JSON.parse(line.slice(6)) as { usage?: { total_tokens?: number } };
          if (chunk.usage?.total_tokens) used = chunk.usage.total_tokens;
        } catch {}
      }
    } else if (response.ok) {
      try {
        const parsed = JSON.parse(body) as { usage?: { total_tokens?: number } };
        used = parsed.usage?.total_tokens ?? 0;
      } catch {}
    }
  } catch {
    status = 0;
  } finally {
    clearTimeout(timer);
  }

  const ms = performance.now() - started;
  samples.push({ ms, status, tokens: used });
  statuses.set(status, (statuses.get(status) ?? 0) + 1);
  tokens += used;
  if (status !== 200) failed += 1;
}

const started = performance.now();
let next = 0;

async function worker(): Promise<void> {
  while (true) {
    const index = next++;
    if (index >= total) return;
    sent += 1;
    await one();
    if (sent % 25 === 0) process.stderr.write(`  sent ${sent}/${total}\n`);
  }
}

process.stderr.write(`load: ${total} requests, concurrency ${concurrency}, stream ${stream}, model ${model}\n`);
await Promise.all(Array.from({ length: Math.min(concurrency, total) }, () => worker()));
const elapsed = performance.now() - started;

const latencies = samples.map((s) => s.ms).sort((a, b) => a - b);
const wall = elapsed / 1000;

console.log("");
console.log(`target        ${url}`);
console.log(`requests      ${samples.length} (${failed} non-200)`);
console.log(`wall          ${wall.toFixed(2)}s`);
console.log(`throughput    ${(samples.length / wall).toFixed(2)} req/s`);
console.log(
  `latency       p50 ${percentile(latencies, 50).toFixed(0)}ms  p90 ${percentile(latencies, 90).toFixed(0)}ms  ` +
    `p99 ${percentile(latencies, 99).toFixed(0)}ms  max ${latencies.at(-1)?.toFixed(0) ?? 0}ms`,
);
console.log(`tokens        ${tokens} (${(tokens / Math.max(1, samples.length)).toFixed(1)}/request)`);
console.log(`statuses      ${[...statuses.entries()].map(([s, n]) => `${s}:${n}`).join(" ")}`);

process.exit(failed === 0 ? 0 : 1);
