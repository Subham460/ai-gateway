#!/usr/bin/env bash
# End-to-end smoke test against a running gateway.
#
#   ./scripts/smoke.sh                     # http://127.0.0.1:8787, key from .env.key
#   OCD_BASE_URL=http://127.0.0.1:9000 ./scripts/smoke.sh
#
# Checks, in order: process reachable, unauthenticated access rejected, models
# listed, one real completion. Exits non-zero on the first failure so it can
# gate CI or a notebook cell.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BASE="${OCD_BASE_URL:-http://127.0.0.1:8787}"
MODEL="${OCD_SMOKE_MODEL:-deepseek-v4.1-flash-free}"
WAIT="${OCD_SMOKE_WAIT:-60}"
KEY="${OCD_KEY:-}"
ANON=0

if [[ -z "$KEY" && -f "$ROOT/.env.key" ]]; then
  KEY="$(cat "$ROOT/.env.key")"
fi
if [[ -f "$ROOT/.env" ]] && grep -q '^OCD_ALLOW_ANONYMOUS=1' "$ROOT/.env" 2>/dev/null; then
  ANON=1
fi

log() { printf '[smoke] %s\n' "$*"; }
fail() { printf '[smoke] FAIL: %s\n' "$*" >&2; exit 1; }

auth=()
if [[ $ANON -eq 0 ]]; then
  [[ -n "$KEY" ]] || fail "no key: pass OCD_KEY=... or run scripts/bootstrap.sh first"
  auth=(-H "authorization: Bearer $KEY")
fi

# 1. reachability
code=000
for _ in $(seq 1 "$WAIT"); do
  code="$(curl -s -o /dev/null -w '%{http_code}' "$BASE/healthz" || true)"
  [[ "$code" == "200" ]] && break
  sleep 1
done
[[ "$code" == "200" ]] || fail "healthz returned $code after ${WAIT}s — is the server running?"
log "healthz 200"

# 2. auth is actually enforced (skip in anonymous mode)
if [[ $ANON -eq 0 ]]; then
  unauth="$(curl -s -o /dev/null -w '%{http_code}' "$BASE/v1/models")"
  [[ "$unauth" == "401" ]] || fail "unauthenticated /v1/models returned $unauth, expected 401"
  log "unauthenticated request rejected (401)"
fi

# 3. catalog
models="$(curl -s "${auth[@]}" "$BASE/v1/models")"
case "$models" in
  *'"object":"list"'*) log "models listed" ;;
  *) fail "unexpected /v1/models body: ${models:0:200}" ;;
esac

# 4. readiness detail
curl -s "$BASE/readyz" >/dev/null 2>&1 && log "readyz ok"

# 5. one completion — this is the only step that spends upstream quota
body="$(curl -s "${auth[@]}" -H 'content-type: application/json' \
  -d "{\"model\":\"$MODEL\",\"messages\":[{\"role\":\"user\",\"content\":\"Reply with the single word: ok\"}],\"max_tokens\":16}" \
  "$BASE/v1/chat/completions")"

case "$body" in
  *'"choices"'*)
    content="$(printf '%s' "$body" | sed -n 's/.*"content":"\([^"]*\)".*/\1/p')"
    log "completion ok: ${content:-<empty>}"
    printf '%s\n' "$body" | head -c 600; printf '\n'
    ;;
  *FreeusageLimit*|*FreeUsageLimit*|*free_usage_limit*)
    fail "upstream throttled the free tier (429). Retry shortly or run: bun run verify:contract"
    ;;
  *)
    fail "unexpected completion body: ${body:0:300}"
    ;;
esac

log "all checks passed"
