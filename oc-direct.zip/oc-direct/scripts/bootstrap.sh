#!/usr/bin/env bash
# One-command bootstrap: install Bun if needed, create a loopback .env with a
# fresh gateway key on first run, then start the gateway in the foreground.
#
#   ./scripts/bootstrap.sh                 # key auth on 127.0.0.1:8787
#   ./scripts/bootstrap.sh --anonymous     # no auth (loopback only)
#   OCD_PORT=9000 ./scripts/bootstrap.sh   # override anything via env
#
# Idempotent: an existing .env is never overwritten. Safe in Colab, Kaggle,
# systemd, and containers; exits non-zero with a reason when something is wrong.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

HOST="${OCD_HOST:-127.0.0.1}"
PORT="${OCD_PORT:-8787}"
ENV_FILE="$ROOT/.env"
KEY_FILE="${OCD_KEY_FILE:-$ROOT/.env.key}"

log() { printf '[bootstrap] %s\n' "$*" >&2; }
die() { printf '[bootstrap] error: %s\n' "$*" >&2; exit 1; }

for arg in "$@"; do
  case "$arg" in
    --anonymous) export OCD_ALLOW_ANONYMOUS=1 ;;
    -h|--help) sed -n '2,10p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) die "unknown argument: $arg" ;;
  esac
done

# ── 1. Bun ───────────────────────────────────────────────────────────────────
if ! command -v bun >/dev/null 2>&1; then
  if [[ -x "$HOME/.bun/bin/bun" ]]; then
    export PATH="$HOME/.bun/bin:$PATH"
  else
    log "bun not found; installing from https://bun.sh"
    command -v curl >/dev/null 2>&1 || die "curl is required to install bun"
    curl -fsSL https://bun.sh/install | bash >/dev/null 2>&1 \
      || die "bun install failed (no network?)"
    export PATH="$HOME/.bun/bin:$PATH"
  fi
fi
command -v bun >/dev/null 2>&1 || die "bun is still not on PATH"
log "bun $(bun --version)"

# ── 2. .env ──────────────────────────────────────────────────────────────────
if [[ -f "$ENV_FILE" ]]; then
  log "using existing .env"
else
  umask 077
  if [[ "${OCD_ALLOW_ANONYMOUS:-0}" == "1" ]]; then
    {
      echo "OCD_ALLOW_ANONYMOUS=1"
      echo "OCD_HOST=$HOST"
      echo "OCD_PORT=$PORT"
      echo "OCD_LOG_LEVEL=${OCD_LOG_LEVEL:-info}"
    } >"$ENV_FILE"
    log "wrote $ENV_FILE (anonymous, loopback only)"
  else
    if [[ -n "${OCD_KEYS:-}" ]]; then
      keys="$OCD_KEYS"
    else
      if command -v openssl >/dev/null 2>&1; then
        secret="$(openssl rand -hex 24)"
      else
        secret="$(bun -e 'console.log(require("node:crypto").randomBytes(24).toString("hex"))')"
      fi
      keys="$secret:default"
    fi
    {
      echo "OCD_KEYS=$keys"
      echo "OCD_HOST=$HOST"
      echo "OCD_PORT=$PORT"
      echo "OCD_LOG_LEVEL=${OCD_LOG_LEVEL:-info}"
    } >"$ENV_FILE"
    umask 022
    printf '%s' "${keys%%:*}" >"$KEY_FILE"
    chmod 600 "$ENV_FILE" "$KEY_FILE"
    log "wrote $ENV_FILE and $KEY_FILE"
  fi
fi

# ── 3. State dir for the derived project id ───────────────────────────────────
if [[ -z "${OCD_STATE_DIR:-}" ]]; then
  export OCD_STATE_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/oc-direct"
fi
mkdir -p "$OCD_STATE_DIR" 2>/dev/null || log "state dir not writable; project id stays in-memory"

log "starting on http://$HOST:$PORT"
exec bash "$ROOT/run.sh"
