/**
 * Contract drift check.
 *
 *   bun run scripts/verify-contract.ts
 *
 * The free tier does not accept arbitrary OpenAI traffic: it attests the request
 * shape before serving. Each negative probe below removes one attested element
 * and must be rejected; the positive probe must be served. If upstream starts
 * serving a negative probe (or rejecting the positive one), the provider has
 * changed its contract and `src/prompt.ts` / `src/ids.ts` need revisiting.
 *
 * Exits non-zero when the observed behaviour differs from the recorded contract.
 */

import { loadConfig } from "../src/config.ts";
import { FREE_MODELS } from "../src/catalog.ts";
import { sessionID } from "../src/ids.ts";
import { CANONICAL_SYSTEM_PROMPT, READ_TOOL } from "../src/prompt.ts";

const config = loadConfig({ OCD_ALLOW_ANONYMOUS: "1" });
const model = FREE_MODELS[0]!.id;

interface Probe {
  name: string;
  expect: "served" | "rejected";
  body: Record<string, unknown>;
  /** Header overrides; `null` removes the header. */
  headers?: Record<string, string | null>;
}

const headers = (session = sessionID()): Record<string, string> => ({
  authorization: "Bearer public",
  "content-type": "application/json",
  "user-agent": config.userAgent,
  "x-opencode-client": config.clientName,
  "x-opencode-project": config.projectId,
  "x-opencode-session-id": session,
  "x-opencode-session": session,
});

const base = (overrides: Record<string, unknown> = {}): Record<string, unknown> => ({
  model,
  messages: [
    { role: "system", content: CANONICAL_SYSTEM_PROMPT },
    { role: "user", content: "Reply with one word: ok" },
  ],
  tools: READ_TOOL,
  tool_choice: "none",
  stream: true,
  stream_options: { include_usage: true },
  max_completion_tokens: 32,
  ...overrides,
});

const probes: Probe[] = [
  { name: "canonical request", expect: "served", body: base() },
  { name: "system prompt replaced by a one-liner", expect: "rejected", body: base({ messages: [{ role: "system", content: "You are helpful." }, { role: "user", content: "hi" }] }) },
  { name: "no tools", expect: "rejected", body: base({ tools: [] }) },
  { name: "only a non-read tool", expect: "rejected", body: base({ tools: [{ type: "function", function: { name: "bash", description: "run a command", parameters: { type: "object", properties: { command: { type: "string" } }, required: ["command"], additionalProperties: false }, strict: false } }] }) },
  { name: "stream disabled", expect: "rejected", body: base({ stream: false }) },
  { name: "random session id", expect: "rejected", body: base(), headers: { "x-opencode-session-id": "ses_000000000000zzzzzzzzzzzzzz", "x-opencode-session": "ses_000000000000zzzzzzzzzzzzzz" } },
];

let failures = 0;

for (const probe of probes) {
  const started = Date.now();
  let status = 0;
  let detail = "";
  try {
    const requestHeaders: Record<string, string> = headers();
    for (const [key, value] of Object.entries(probe.headers ?? {})) {
      if (value === null) delete requestHeaders[key];
      else requestHeaders[key] = value;
    }
    const response = await fetch(`${config.upstreamUrl}/chat/completions`, {
      method: "POST",
      headers: requestHeaders,
      body: JSON.stringify(probe.body),
    });
    status = response.status;
    const text = await response.text();
    try {
      const parsed = JSON.parse(text) as { error?: { type?: string; message?: string } };
      detail = parsed.error?.type ?? parsed.error?.message ?? "";
    } catch {
      detail = text.slice(0, 80);
    }
  } catch (error) {
    detail = (error as Error).message;
  }

  const served = status === 200;
  const observed = served ? "served" : "rejected";
  const ok = observed === probe.expect;
  if (!ok) failures += 1;
  const label = ok ? "OK  " : "DRIFT";
  console.log(
    `${label}  ${probe.name.padEnd(42)} ${observed.padEnd(9)} (${status} ${detail}) ${Date.now() - started}ms`,
  );
}

console.log("");
if (failures > 0) {
  console.log(`contract drift detected in ${failures} probe(s): update src/prompt.ts / src/ids.ts`);
  process.exit(1);
}
console.log("contract unchanged: all probes match the recorded wire requirements");
