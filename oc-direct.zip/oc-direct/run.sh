#!/usr/bin/env bash
# Local launcher: loads .env when present, generates a key on first run, then
# execs the service so signals reach it directly.
set -euo pipefail

cd "$(dirname "$0")"

if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
elif [[ "${OCD_ALLOW_ANONYMOUS:-0}" != "1" && -z "${OCD_KEYS:-}" ]]; then
  echo "no .env found; starting in loopback anonymous mode (set OCD_KEYS for auth)" >&2
  export OCD_ALLOW_ANONYMOUS=1
fi

export OCD_HOST="${OCD_HOST:-127.0.0.1}"
export OCD_PORT="${OCD_PORT:-8787}"

if ! command -v bun >/dev/null 2>&1; then
  if [[ -x "$HOME/.bun/bin/bun" ]]; then
    export PATH="$HOME/.bun/bin:$PATH"
  else
    echo "bun is required: https://bun.sh/docs/installation" >&2
    exit 1
  fi
fi

exec bun run src/server.ts
