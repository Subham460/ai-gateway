import { describe, expect, test } from "bun:test";
import { BadRequestError } from "../src/errors.ts";
import { resolveModel } from "../src/catalog.ts";
import {
  CANONICAL_SYSTEM_PROMPT,
  MAX_COMPLETION_TOKENS,
  READ_TOOL,
  buildUpstreamBody,
} from "../src/prompt.ts";

const model = resolveModel("deepseek-v4.1-flash-free", false)!;
const options = { toolsMode: "read" as const, toolChoice: "none" as const, defaultMaxTokens: 32_000 };

const built = (messages: unknown[], extra: Record<string, unknown> = {}) =>
  JSON.parse(
    buildUpstreamBody({ model: model.id, messages, ...extra } as never, model, options).body,
  );

describe("canonical assets", () => {
  test("system prompt is the captured 8,605-character artifact", () => {
    expect(CANONICAL_SYSTEM_PROMPT.length).toBe(8605);
    expect(CANONICAL_SYSTEM_PROMPT.startsWith("You are an AI agent running in OpenCode")).toBe(true);
  });

  test("read tool is present and alone in read mode", () => {
    expect(READ_TOOL).toHaveLength(1);
    const tool = READ_TOOL[0] as { type: string; function: { name: string; parameters: unknown } };
    expect(tool.type).toBe("function");
    expect(tool.function.name).toBe("read");
    expect(tool.function.parameters).toBeDefined();
  });
});

describe("buildUpstreamBody", () => {
  test("always streams with usage", () => {
    const body = built([{ role: "user", content: "hi" }]);
    expect(body.stream).toBe(true);
    expect(body.stream_options).toEqual({ include_usage: true });
    expect(body.tool_choice).toBe("none");
    expect(body.model).toBe("deepseek-v4.1-flash-free");
  });

  test("prepends the canonical system prompt verbatim", () => {
    const body = built([{ role: "user", content: "hi" }]);
    expect(body.messages[0].role).toBe("system");
    expect(body.messages[0].content).toBe(CANONICAL_SYSTEM_PROMPT);
    expect(body.messages[1]).toEqual({ role: "user", content: "hi" });
  });

  test("appends caller system text under a user-instructions heading", () => {
    const body = built([
      { role: "system", content: "You are terse." },
      { role: "user", content: "hi" },
    ]);
    expect(body.messages[0].content.startsWith(CANONICAL_SYSTEM_PROMPT)).toBe(true);
    expect(body.messages[0].content).toEndWith("# User Instructions\nYou are terse.");
  });

  test("preserves multi-turn history", () => {
    const body = built([
      { role: "user", content: "My name is Ada." },
      { role: "assistant", content: "Hello Ada." },
      { role: "user", content: "What is my name?" },
    ]);
    expect(body.messages).toHaveLength(4);
    expect(body.messages[1]).toEqual({ role: "user", content: "My name is Ada." });
    expect(body.messages[2]).toEqual({ role: "assistant", content: "Hello Ada." });
  });

  test("flattens tool results into user turns", () => {
    const body = built([
      { role: "user", content: "read the file" },
      { role: "tool", name: "read", content: "file contents" },
    ]);
    expect(body.messages[2]).toEqual({ role: "user", content: "Tool result (read):\nfile contents" });
  });

  test("flattens content-part arrays and marks images", () => {
    const body = built([
      {
        role: "user",
        content: [
          { type: "text", text: "describe" },
          { type: "image_url", image_url: { url: "data:image/png;base64,AAAA" } },
        ],
      },
    ]);
    expect(body.messages[1].content).toContain("describe");
    expect(body.messages[1].content).toContain("[image omitted");
  });

  test("clamps max tokens to the model ceiling", () => {
    expect(built([{ role: "user", content: "hi" }], { max_completion_tokens: 999_999 }).max_completion_tokens).toBe(
      Math.min(MAX_COMPLETION_TOKENS, model.maxOutputTokens),
    );
    expect(built([{ role: "user", content: "hi" }], { max_completion_tokens: 12 }).max_completion_tokens).toBe(12);
    expect(built([{ role: "user", content: "hi" }], { max_tokens: 33 }).max_completion_tokens).toBe(33);
  });

  test("rejects malformed conversations", () => {
    expect(() => built([])).toThrow(BadRequestError);
    expect(() => built([{ role: "assistant", content: "hi" }])).toThrow(BadRequestError);
    expect(() => built([{ role: "wizard", content: "hi" }])).toThrow(BadRequestError);
    expect(() => built([{ role: "user", content: "   " }])).toThrow(BadRequestError);
  });
});
